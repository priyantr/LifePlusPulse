# **App Name**: Life+ Pulse

## Core Features:

- Sedentary Interval Pulse: Customizable sedentary timer with 15–120 minute range, utilizing a smooth interaction slider for immediate session control.
- Hydration Goal Velocity: Daily water tracking module with intake logging and visual progress monitoring against hydration targets.
- Intelligent Task Scheduler: Dynamic task management system with support for repeating reminders and high-priority voice-to-user alerts.
- Vocal Tone Persona AI: Generative AI tool that acts as a linguistic engine to synthesize natural or sarcastic motivation scripts based on the user's selected personality mode.
- Precision Notification Core: Foreground service integration for Android that ensures notifications and TTS reminders trigger exactly when requested, even during lock states.
- System Reliability Panel: A centralized control dashboard to manage battery optimizations and notification permissions specifically optimized for high-end Samsung hardware.

## Style Guidelines:

- The palette is rooted in 'High-Performance Vitality'. The primary color is a deep, energized Indigo (#4F46E5) to establish focus.
- Background is a sophisticated Deep Indigo-Navy (#0E0E1B), providing the high-contrast professional look requested for S23 Ultra displays.
- The accent color is a sharp Cerulean (#36ABF9), 30 degrees analogous from the primary, used for highlighting interactive elements.
- The application uses 'Space Grotesk' for headings to convey a techy, precise feel, and 'Inter' for body text to maintain maximum legibility at high data density.
- Vector-based, high-definition thin-stroke icons that switch color context (Green/Blue/Orange) based on the specific health vertical being tracked.
- Modular bento-box dashboard layout, optimized for high vertical aspect ratios with large touch targets for easy navigation.
- High-framerate CSS-driven transitions that mirror the tactile feedback of native OS motions, specifically tuned for 120Hz refresh rates.