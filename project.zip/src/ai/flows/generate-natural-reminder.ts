
// AI Flow Disabled
export const generateNaturalReminder = async () => ({ message: "Time to move!" });
