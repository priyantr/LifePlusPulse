
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, triggerAlarm, dismissAlarm, snoozeAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const loopRef = useRef<NodeJS.Timeout | null>(null);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined' || !text || !settings.voiceEnabled) return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        const voices = await TextToSpeech.getSupportedVoices();
        const preferred = voices.voices.find(v => 
          v.name.toLowerCase().includes('google') || 
          v.name.toLowerCase().includes('enhanced') || 
          v.name.toLowerCase().includes('neural')
        );

        await TextToSpeech.speak({
          text,
          lang: settings.voiceGender === 'female' ? 'en-GB' : 'en-US',
          rate: 1.0,
          pitch: 1.0,
          volume: settings.volumeBoost,
          voice: preferred?.name,
          category: 'alarm'
        });
      } catch (e) {}
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = settings.volumeBoost;
      window.speechSynthesis.speak(utterance);
    }
  }, [settings, isNative]);

  const stopSpeak = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  // ABSOLUTE ALARM LOOP
  useEffect(() => {
    if (isAlarmActive && activeAlarmMessage) {
      const run = () => {
        if (!isAlarmActive) return;
        speak(activeAlarmMessage);
        // Loop every 10 seconds for high-priority alarm behavior
        loopRef.current = setTimeout(run, 10000);
      };
      run();

      // 5-minute safety cutoff to prevent infinite battery drain
      const safetyTimeout = setTimeout(() => {
        if (isAlarmActive) dismissAlarm();
      }, 300000);

      return () => {
        if (loopRef.current) clearTimeout(loopRef.current);
        clearTimeout(safetyTimeout);
      };
    } else {
      if (loopRef.current) clearTimeout(loopRef.current);
      stopSpeak();
    }
  }, [isAlarmActive, activeAlarmMessage, speak, stopSpeak, dismissAlarm]);

  // NATIVE ACTION HANDLERS
  useEffect(() => {
    if (!isNative) return;
    let r: any, p: any;
    const setup = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALARM_V10',
          actions: [
            { id: 'stop', title: 'STOP ALARM', destructive: true },
            { id: 'snooze', title: 'SNOOZE (5m)' }
          ]
        }]
      });

      r = await LocalNotifications.addListener('localNotificationReceived', (n) => {
        const type = n.id === 1001 ? 'sedentary' : n.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, n.body || "Pulse Alert");
      });

      p = await LocalNotifications.addListener('localNotificationActionPerformed', (a) => {
        if (a.actionId === 'stop') {
          dismissAlarm();
        } else if (a.actionId === 'snooze') {
          const type = a.notification.id === 1001 ? 'sedentary' : a.notification.id === 1002 ? 'water' : 'task';
          snoozeAlarm(type as any, a.notification.body || "");
        } else {
          const type = a.notification.id === 1001 ? 'sedentary' : a.notification.id === 1002 ? 'water' : 'task';
          triggerAlarm(type as any, a.notification.body || "Pulse Alert");
        }
      });
    };
    setup();
    return () => { if (r) r.remove(); if (p) p.remove(); };
  }, [isNative, triggerAlarm, dismissAlarm, snoozeAlarm]);

  const scheduleNative = useCallback(async (type: PulseType, context?: string, delay: number = 0) => {
    const msg = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Water Pulse" : "Move Pulse";
    const id = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 900000) + 1003;

    if (isNative) {
      try {
        const { LocalNotifications } = await import('@capacitor/local-notifications');
        // CRITICAL: Cancel existing to prevent ghost triggers
        await LocalNotifications.cancel({ notifications: [{ id }] });
        
        await LocalNotifications.schedule({
          notifications: [{
            title, body: msg, id,
            schedule: delay > 0 ? { at: new Date(Date.now() + delay * 1000), allowWhileIdle: true } : undefined,
            sound: 'beep.wav',
            importance: 5,
            ongoing: true, // Behaves more like an alarm
            actionTypeId: 'PULSE_ALARM_V10'
          }]
        });
      } catch (e) {}
    } else if (delay > 0) {
      setTimeout(() => triggerAlarm(type, msg), delay * 1000);
    } else {
      triggerAlarm(type, msg);
    }
    
    if (delay === 0) toast({ title, description: msg });
  }, [settings.personality, isNative, triggerAlarm, toast]);

  const cancelNative = useCallback(async (id: number) => {
    if (!isNative) return;
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      await LocalNotifications.cancel({ notifications: [{ id }] });
    } catch (e) {}
  }, [isNative]);

  return { triggerAlert: scheduleNative, cancelNotification: cancelNative, speak, dismissAlarm };
}
