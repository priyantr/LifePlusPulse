
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, triggerAlarm, dismissAlarm, snoozeAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const voiceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const autoDismissRef = useRef<NodeJS.Timeout | null>(null);

  const stopAllAudio = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined' || !text) return;

    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        
        // Priority high-quality voice profiles
        const lang = settings.voiceGender === 'female' ? 'en-GB' : 'en-US';
        const rate = settings.voiceProfile === 'strict' ? 1.15 : settings.voiceProfile === 'funny' ? 1.1 : 1.0;
        
        await TextToSpeech.speak({
          text,
          lang,
          rate,
          volume: settings.volumeBoost,
          category: 'alarm', // High priority audio category
        });
      } catch (e) {
        console.warn("Native TTS error:", e);
      }
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = settings.volumeBoost;
        utterance.lang = settings.voiceGender === 'female' ? 'en-GB' : 'en-US';
        utterance.rate = settings.voiceProfile === 'strict' ? 1.15 : 1.0;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [settings.voiceGender, settings.voiceProfile, settings.volumeBoost, isNative]);

  // ALARM LIFECYCLE: Recursive loop every 12 seconds
  useEffect(() => {
    if (isAlarmActive && activeAlarmMessage && settings.voiceEnabled) {
      // Initial speak
      speak(activeAlarmMessage);

      // Recursive loop
      const runAlarmLoop = () => {
        if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
        voiceTimeoutRef.current = setTimeout(() => {
          if (isAlarmActive) {
            speak(activeAlarmMessage);
            runAlarmLoop();
          }
        }, 12000); // 12-second alarm interval
      };
      runAlarmLoop();

      // AUTO-DISMISS SAFETY: 5 minutes (as requested)
      if (autoDismissRef.current) clearTimeout(autoDismissRef.current);
      autoDismissRef.current = setTimeout(() => {
        dismissAlarm();
      }, 300000); // 5 minutes

    } else {
      // Clean up immediately when inactive
      if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
      if (autoDismissRef.current) clearTimeout(autoDismissRef.current);
      stopAllAudio();
    }

    return () => {
      if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
      if (autoDismissRef.current) clearTimeout(autoDismissRef.current);
    };
  }, [isAlarmActive, activeAlarmMessage, speak, stopAllAudio, settings.voiceEnabled, dismissAlarm]);

  // NATIVE LISTENERS: Bridges notification to the Alarm UI and Voice
  useEffect(() => {
    if (!isNative) return;

    let receivedListener: any;
    let performedListener: any;

    const setupListeners = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // Define alarm-style actions
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALARM_ACTIONS_V2',
          actions: [
            { id: 'stop', title: 'STOP', destructive: true },
            { id: 'snooze', title: 'SNOOZE (5m)' }
          ]
        }]
      });

      // Background listener (fires when app is minimized or backgrounded)
      receivedListener = await LocalNotifications.addListener('localNotificationReceived', (notification) => {
        const type = notification.id === 1001 ? 'sedentary' : notification.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, notification.body || "Pulse Alert");
      });

      // User interaction listener (fires when notification or action tapped)
      performedListener = await LocalNotifications.addListener('localNotificationActionPerformed', async (action) => {
        const type = action.notification.id === 1001 ? 'sedentary' : action.notification.id === 1002 ? 'water' : 'task';
        
        if (action.actionId === 'stop') {
          dismissAlarm();
        } else if (action.actionId === 'snooze') {
          snoozeAlarm();
          // Reschedule exactly in 5 mins
          triggerAlert(type as any, action.notification.body || undefined, 300);
        } else {
          // Normal tap opens app and starts alarm state
          triggerAlarm(type as any, action.notification.body || "Pulse Alert");
        }
      });
    };

    setupListeners();

    return () => {
      if (receivedListener) receivedListener.remove();
      if (performedListener) performedListener.remove();
    };
  }, [isNative, triggerAlarm, dismissAlarm, snoozeAlarm]);

  const triggerAlert = useCallback(async (type: PulseType, context?: string, delaySeconds: number = 0) => {
    if (typeof window === 'undefined') return;

    const message = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Pulse: Goal Alert" : type === 'water' ? "Pulse: Hydration" : "Pulse: Vitality";
    const notificationId = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 900000) + 1003;

    // Instant trigger logic
    if (delaySeconds === 0) {
      toast({ title, description: message });
      triggerAlarm(type, message);
    }

    if (!isNative) {
      if (delaySeconds > 0) {
        setTimeout(() => {
          toast({ title, description: message });
          triggerAlarm(type, message);
        }, delaySeconds * 1000);
      }
      return;
    }

    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // Deduplicate: remove any existing alert of this type
      await LocalNotifications.cancel({ notifications: [{ id: notificationId }] });

      await LocalNotifications.schedule({
        notifications: [{
          title,
          body: message,
          id: notificationId,
          schedule: delaySeconds > 0 ? { 
            at: new Date(Date.now() + delaySeconds * 1000), 
            allowWhileIdle: true 
          } : undefined,
          sound: 'beep.wav',
          importance: 5, // Max importance
          actionTypeId: 'PULSE_ALARM_ACTIONS_V2'
        }]
      });
    } catch (e) {
      console.error("Native scheduling failed:", e);
    }
  }, [triggerAlarm, settings.personality, toast, isNative]);

  return { triggerAlert, speak, dismissAlarm, snoozeAlarm };
}
