"use client";

import { useCallback, useEffect } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, alarmStartedAt, triggerAlarm, dismissAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined') return;

    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.speak({
          text,
          lang: settings.voiceGender === 'female' ? 'en-GB' : 'en-US',
          rate: 1.0,
          volume: settings.volumeBoost,
          category: 'ambient',
        });
      } catch (e) {
        console.warn("Native TTS error:", e);
      }
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = settings.volumeBoost;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [settings.voiceGender, settings.volumeBoost, isNative]);

  // Handle auto-dismiss after 60 seconds of activity
  useEffect(() => {
    if (isAlarmActive && alarmStartedAt) {
      const timeout = setTimeout(() => {
        dismissAlarm();
      }, 60000);
      return () => clearTimeout(timeout);
    }
  }, [isAlarmActive, alarmStartedAt, dismissAlarm]);

  // Handle repeating voice loop while alarm is active
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    
    const runLoop = async () => {
      if (isAlarmActive && activeAlarmMessage && settings.voiceEnabled) {
        await speak(activeAlarmMessage);
        // Repeat every 12 seconds
        timeoutId = setTimeout(runLoop, 12000);
      }
    };

    if (isAlarmActive) {
      runLoop();
    } else {
      // Immediate cleanup when alarm state is cleared
      if (isNative) {
        import('@capacitor-community/text-to-speech').then(({ TextToSpeech }) => {
          TextToSpeech.stop();
        }).catch(() => {});
      } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [isAlarmActive, activeAlarmMessage, speak, settings.voiceEnabled, isNative]);

  // Native Notification Listeners to bridge Background -> TTS
  useEffect(() => {
    if (!isNative) return;

    let receivedListener: any;
    let performedListener: any;

    const setupListeners = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      receivedListener = await LocalNotifications.addListener('localNotificationReceived', (notification) => {
        const type = notification.id === 1001 ? 'sedentary' : notification.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, notification.body || "Pulse Alert");
      });

      performedListener = await LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
        if (action.actionId === 'dismiss') {
          dismissAlarm();
        } else {
          const type = action.notification.id === 1001 ? 'sedentary' : action.notification.id === 1002 ? 'water' : 'task';
          triggerAlarm(type as any, action.notification.body || "Pulse Alert");
        }
      });
    };

    setupListeners();

    return () => {
      if (receivedListener) receivedListener.remove();
      if (performedListener) performedListener.remove();
    };
  }, [isNative, triggerAlarm, dismissAlarm]);

  const triggerAlert = useCallback(async (type: PulseType, context?: string, delaySeconds: number = 0) => {
    if (typeof window === 'undefined') return;

    const message = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Hydration Pulse" : "Move Pulse";
    const notificationId = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 1000000);

    if (delaySeconds === 0) {
      toast({ title, description: message });
      triggerAlarm(type, message);
    }

    if (!isNative) {
      if (delaySeconds > 0) {
        setTimeout(() => {
          toast({ title, description: message });
          triggerAlarm(type, message);
        }, delaySeconds * 1000);
      }
      return;
    }

    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALERT',
          actions: [{ id: 'dismiss', title: 'Dismiss Reminder', destructive: true }]
        }]
      });

      await LocalNotifications.schedule({
        notifications: [{
          title,
          body: message,
          id: notificationId,
          schedule: delaySeconds > 0 ? { 
            at: new Date(Date.now() + delaySeconds * 1000), 
            allowWhileIdle: true 
          } : undefined,
          sound: 'beep.wav',
          importance: 5,
          actionTypeId: 'PULSE_ALERT'
        }]
      });
    } catch (e) {
      console.error("Native notification error:", e);
    }
  }, [triggerAlarm, settings.personality, toast, isNative]);

  return { triggerAlert, speak, dismissAlarm };
}
