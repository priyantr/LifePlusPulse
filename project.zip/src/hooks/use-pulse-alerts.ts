
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore, type PulseType } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage } from "@/lib/personality";

export function usePulseAlerts() {
  const { 
    settings, isAlarmActive, activeAlarmMessage, activeAlarmType, 
    triggerAlarm, dismissAlarm, snoozeAlarm,
    isMoveTimerActive, moveTargetTimestamp, isMoveTimerPaused,
    isWaterTimerActive, waterTargetTimestamp, isWaterTimerPaused
  } = useAppStore();
  
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const loopRef = useRef<NodeJS.Timeout | null>(null);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined' || !text || !settings.voiceEnabled) return;
    
    return new Promise<void>(async (resolve) => {
      if (isNative) {
        try {
          const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
          await TextToSpeech.stop();
          
          const voices = await TextToSpeech.getSupportedVoices();
          const preferred = voices.voices.find(v => 
            v.name.toLowerCase().includes('google') || 
            v.name.toLowerCase().includes('enhanced') || 
            v.name.toLowerCase().includes('neural')
          );

          await TextToSpeech.speak({
            text,
            lang: 'en-US',
            rate: 1.0,
            pitch: 1.0,
            volume: settings.volumeBoost,
            voice: preferred?.name,
            category: 'alarm'
          });
          // Small buffer to ensure completion
          setTimeout(resolve, 500);
        } catch (e) {
          console.error("TTS Error:", e);
          resolve();
        }
      } else if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = settings.volumeBoost;
        utterance.onend = () => resolve();
        window.speechSynthesis.speak(utterance);
      } else {
        resolve();
      }
    });
  }, [settings, isNative]);

  const stopSpeak = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  // RECURSIVE ALARM LOOP (1S GAP)
  useEffect(() => {
    let active = true;

    const runAlarmLoop = async () => {
      if (!active || !isAlarmActive || !activeAlarmMessage) return;
      
      await speak(activeAlarmMessage);
      
      if (active && isAlarmActive) {
        // 1 second gap between repeats for high urgency
        loopRef.current = setTimeout(runAlarmLoop, 1000);
      }
    };

    if (isAlarmActive && activeAlarmMessage) {
      runAlarmLoop();
      
      // 5-minute safety hardware cutoff
      const safety = setTimeout(() => {
        if (isAlarmActive) dismissAlarm();
      }, 300000);

      return () => {
        active = false;
        if (loopRef.current) clearTimeout(loopRef.current);
        clearTimeout(safety);
        stopSpeak();
      };
    } else {
      active = false;
      if (loopRef.current) clearTimeout(loopRef.current);
      stopSpeak();
    }
  }, [isAlarmActive, activeAlarmMessage, speak, stopSpeak, dismissAlarm]);

  // NATIVE BACKGROUND ACTION LISTENERS
  useEffect(() => {
    if (!isNative) return;
    let r: any, p: any;
    
    const setup = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALARM_ACTION',
          actions: [
            { id: 'stop', title: 'STOP ALARM', destructive: true },
            { id: 'snooze', title: 'SNOOZE (5M)' }
          ]
        }]
      });

      r = await LocalNotifications.addListener('localNotificationReceived', (n) => {
        const type = n.id === 1001 ? 'sedentary' : n.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as PulseType, n.body || "Pulse Alert");
      });

      p = await LocalNotifications.addListener('localNotificationActionPerformed', (a) => {
        const type = a.notification.id === 1001 ? 'sedentary' : a.notification.id === 1002 ? 'water' : 'task';
        if (a.actionId === 'stop') {
          dismissAlarm(type as PulseType);
        } else if (a.actionId === 'snooze') {
          snoozeAlarm(type as PulseType, a.notification.body || "");
        } else {
          triggerAlarm(type as PulseType, a.notification.body || "Pulse Alert");
        }
      });
    };
    
    setup();
    return () => { if (r) r.remove(); if (p) p.remove(); };
  }, [isNative, triggerAlarm, dismissAlarm, snoozeAlarm]);

  const scheduleNative = useCallback(async (type: PulseType, context?: string, delay: number = 0) => {
    const msg = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Water Pulse" : "Move Pulse";
    const id = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : 1003;

    if (isNative) {
      try {
        const { LocalNotifications } = await import('@capacitor/local-notifications');
        
        await LocalNotifications.cancel({ notifications: [{ id }] });
        
        if (delay > 0) {
          await LocalNotifications.schedule({
            notifications: [{
              title,
              body: msg,
              id,
              schedule: { at: new Date(Date.now() + (delay * 1000)), allowWhileIdle: true },
              sound: 'beep.wav',
              importance: 5,
              actionTypeId: 'PULSE_ALARM_ACTION'
            }]
          });
        } else {
          triggerAlarm(type, msg);
        }
      } catch (e) {
        console.error("Scheduling Error:", e);
      }
    } else {
      if (delay > 0) {
        setTimeout(() => triggerAlarm(type, msg), delay * 1000);
      } else {
        triggerAlarm(type, msg);
      }
    }
    
    if (delay === 0) toast({ title, description: msg });
  }, [settings.personality, isNative, triggerAlarm, toast]);

  // SYNC ENGINE: ENSURE RECURRING CYCLES ARE REGISTERED NATIVELY
  useEffect(() => {
    if (!isNative || isAlarmActive) return;

    // Sync Sedentary
    if (isMoveTimerActive && moveTargetTimestamp && !isMoveTimerPaused) {
      const delay = Math.max(0, Math.floor((moveTargetTimestamp - Date.now()) / 1000));
      if (delay > 0) {
        scheduleNative('sedentary', undefined, delay);
      }
    }

    // Sync Water
    if (isWaterTimerActive && waterTargetTimestamp && !isWaterTimerPaused) {
      const delay = Math.max(0, Math.floor((waterTargetTimestamp - Date.now()) / 1000));
      if (delay > 0) {
        scheduleNative('water', undefined, delay);
      }
    }
  }, [
    isNative, isAlarmActive, 
    isMoveTimerActive, moveTargetTimestamp, isMoveTimerPaused,
    isWaterTimerActive, waterTargetTimestamp, isWaterTimerPaused,
    scheduleNative
  ]);

  const cancelNative = useCallback(async (id: number) => {
    if (!isNative) return;
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      await LocalNotifications.cancel({ notifications: [{ id }] });
    } catch (e) {}
  }, [isNative]);

  return { triggerAlert: scheduleNative, cancelNotification: cancelNative, speak, dismissAlarm };
}
