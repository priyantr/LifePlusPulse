
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, alarmStartedAt, triggerAlarm, dismissAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const voiceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const autoDismissRef = useRef<NodeJS.Timeout | null>(null);

  const stopAllAudio = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined') return;

    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.speak({
          text,
          lang: settings.voiceGender === 'female' ? 'en-GB' : 'en-US',
          rate: 1.0,
          volume: settings.volumeBoost,
          category: 'ambient',
        });
      } catch (e) {
        console.warn("Native TTS error:", e);
      }
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = settings.volumeBoost;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [settings.voiceGender, settings.volumeBoost, isNative]);

  // Handle Alarm Loop Lifecycle
  useEffect(() => {
    if (isAlarmActive && activeAlarmMessage && settings.voiceEnabled) {
      // 1. Initial Voice Trigger
      speak(activeAlarmMessage);

      // 2. Start Repeating Loop (every 12 seconds)
      const runLoop = () => {
        if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
        voiceTimeoutRef.current = setTimeout(() => {
          speak(activeAlarmMessage);
          runLoop();
        }, 12000);
      };
      runLoop();

      // 3. Safety Auto-Dismiss (after 60 seconds)
      if (autoDismissRef.current) clearTimeout(autoDismissRef.current);
      autoDismissRef.current = setTimeout(() => {
        dismissAlarm();
      }, 60000);
    } else {
      // Cleanup when alarm is stopped
      if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
      if (autoDismissRef.current) clearTimeout(autoDismissRef.current);
      stopAllAudio();
    }

    return () => {
      if (voiceTimeoutRef.current) clearTimeout(voiceTimeoutRef.current);
      if (autoDismissRef.current) clearTimeout(autoDismissRef.current);
    };
  }, [isAlarmActive, activeAlarmMessage, speak, stopAllAudio, settings.voiceEnabled, dismissAlarm]);

  // Native Notification Listeners (Bridge Background -> UI/Voice Alarm)
  useEffect(() => {
    if (!isNative) return;

    let receivedListener: any;
    let performedListener: any;

    const setupListeners = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALERT_ACTIONS',
          actions: [{
            id: 'dismiss',
            title: 'Dismiss Reminder',
            destructive: true,
          }]
        }]
      });

      receivedListener = await LocalNotifications.addListener('localNotificationReceived', (notification) => {
        const type = notification.id === 1001 ? 'sedentary' : notification.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, notification.body || "Pulse Alert");
      });

      performedListener = await LocalNotifications.addListener('localNotificationActionPerformed', (action) => {
        if (action.actionId === 'dismiss') {
          dismissAlarm();
        } else {
          const type = action.notification.id === 1001 ? 'sedentary' : action.notification.id === 1002 ? 'water' : 'task';
          triggerAlarm(type as any, action.notification.body || "Pulse Alert");
        }
      });
    };

    setupListeners();

    return () => {
      if (receivedListener) receivedListener.remove();
      if (performedListener) performedListener.remove();
    };
  }, [isNative, triggerAlarm, dismissAlarm]);

  const triggerAlert = useCallback(async (type: PulseType, context?: string, delaySeconds: number = 0) => {
    if (typeof window === 'undefined') return;

    const message = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Hydration Pulse" : "Move Pulse";
    const notificationId = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 1000000);

    // If zero delay, start alarm immediately
    if (delaySeconds === 0) {
      toast({ title, description: message });
      triggerAlarm(type, message);
    }

    if (!isNative) {
      if (delaySeconds > 0) {
        setTimeout(() => {
          toast({ title, description: message });
          triggerAlarm(type, message);
        }, delaySeconds * 1000);
      }
      return;
    }

    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // Clean up any stale notification of same type
      await LocalNotifications.cancel({ notifications: [{ id: notificationId }] });

      await LocalNotifications.schedule({
        notifications: [{
          title,
          body: message,
          id: notificationId,
          schedule: delaySeconds > 0 ? { 
            at: new Date(Date.now() + delaySeconds * 1000), 
            allowWhileIdle: true 
          } : undefined,
          sound: 'beep.wav',
          importance: 5,
          actionTypeId: 'PULSE_ALERT_ACTIONS'
        }]
      });
    } catch (e) {
      console.error("Native notification error:", e);
    }
  }, [triggerAlarm, settings.personality, toast, isNative]);

  return { triggerAlert, speak, dismissAlarm };
}
