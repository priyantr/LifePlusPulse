
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, triggerAlarm, dismissAlarm, snoozeAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const loopRef = useRef<NodeJS.Timeout | null>(null);
  const safetyRef = useRef<NodeJS.Timeout | null>(null);

  const stopAudio = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined' || !text) return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        const rate = settings.voiceProfile === 'strict' ? 1.15 : settings.voiceProfile === 'funny' ? 1.05 : 1.0;
        await TextToSpeech.speak({
          text,
          lang: settings.voiceGender === 'female' ? 'en-GB' : 'en-US',
          rate,
          volume: settings.volumeBoost,
          category: 'alarm',
        });
      } catch (e) {}
    } else if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = settings.volumeBoost;
      utterance.lang = settings.voiceGender === 'female' ? 'en-GB' : 'en-US';
      window.speechSynthesis.speak(utterance);
    }
  }, [settings.voiceGender, settings.voiceProfile, settings.volumeBoost, isNative]);

  // RECURSIVE ALARM ENGINE (REPEATS EVERY 12s)
  useEffect(() => {
    if (isAlarmActive && activeAlarmMessage && settings.voiceEnabled) {
      const run = () => {
        if (!isAlarmActive) return;
        speak(activeAlarmMessage);
        if (loopRef.current) clearTimeout(loopRef.current);
        loopRef.current = setTimeout(run, 12000); 
      };
      run();

      // 5-Minute Safety Stop
      if (safetyRef.current) clearTimeout(safetyRef.current);
      safetyRef.current = setTimeout(() => {
        dismissAlarm();
      }, 300000); 
    } else {
      if (loopRef.current) clearTimeout(loopRef.current);
      if (safetyRef.current) clearTimeout(safetyRef.current);
      stopAudio();
    }
    return () => {
      if (loopRef.current) clearTimeout(loopRef.current);
      if (safetyRef.current) clearTimeout(safetyRef.current);
    };
  }, [isAlarmActive, activeAlarmMessage, speak, stopAudio, settings.voiceEnabled, dismissAlarm]);

  // NATIVE BACKGROUND LISTENERS & ACTIONS
  useEffect(() => {
    if (!isNative) return;
    let r: any, p: any;
    const setup = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // Register NATIVE ALARM ACTIONS (Survives minimize)
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALARM_ACTIONS_V6',
          actions: [
            { id: 'stop', title: 'STOP PULSE', destructive: true },
            { id: 'snooze', title: 'SNOOZE (5m)' }
          ]
        }]
      });

      r = await LocalNotifications.addListener('localNotificationReceived', (n) => {
        const type = n.id === 1001 ? 'sedentary' : n.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, n.body || "Pulse Alert");
      });

      p = await LocalNotifications.addListener('localNotificationActionPerformed', async (a) => {
        if (a.actionId === 'stop') {
          dismissAlarm();
        } else if (a.actionId === 'snooze') {
          snoozeAlarm();
          schedule('task', a.notification.body || "Pulse", 300);
        } else {
          // Re-trigger alarm state if notification is simply tapped
          const type = a.notification.id === 1001 ? 'sedentary' : a.notification.id === 1002 ? 'water' : 'task';
          triggerAlarm(type as any, a.notification.body || "Pulse Alert");
        }
      });
    };
    setup();
    return () => { if (r) r.remove(); if (p) p.remove(); };
  }, [isNative, triggerAlarm, dismissAlarm, snoozeAlarm]);

  const schedule = useCallback(async (type: PulseType, context?: string, delay: number = 0) => {
    const msg = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Water Pulse" : "Move Pulse";
    const id = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 900000) + 1003;

    if (delay === 0) {
      toast({ title, description: msg });
      triggerAlarm(type, msg);
    }

    if (isNative) {
      try {
        const { LocalNotifications } = await import('@capacitor/local-notifications');
        // Explicitly cancel previous to prevent isolation bugs
        await LocalNotifications.cancel({ notifications: [{ id }] });
        await LocalNotifications.schedule({
          notifications: [{
            title, body: msg, id,
            schedule: delay > 0 ? { at: new Date(Date.now() + delay * 1000), allowWhileIdle: true } : undefined,
            sound: 'beep.wav',
            importance: 5, 
            actionTypeId: 'PULSE_ALARM_ACTIONS_V6'
          }]
        });
      } catch (e) {}
    } else if (delay > 0) {
      setTimeout(() => triggerAlarm(type, msg), delay * 1000);
    }
  }, [triggerAlarm, settings.personality, toast, isNative]);

  const cancel = useCallback(async (id: number) => {
    if (!isNative) return;
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      await LocalNotifications.cancel({ notifications: [{ id }] });
    } catch (e) {}
  }, [isNative]);

  return { triggerAlert: schedule, cancelNotification: cancel, speak, dismissAlarm, snoozeAlarm };
}
