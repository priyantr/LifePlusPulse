
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, triggerAlarm, dismissAlarm, snoozeAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const voiceLoopRef = useRef<NodeJS.Timeout | null>(null);
  const safetyTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const stopAllAudio = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined' || !text) return;

    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        
        // Priority high-quality mapping
        const lang = settings.voiceGender === 'female' ? 'en-GB' : 'en-US';
        const rate = settings.voiceProfile === 'strict' ? 1.15 : settings.voiceProfile === 'funny' ? 1.1 : 1.0;
        
        await TextToSpeech.speak({
          text,
          lang,
          rate,
          volume: settings.volumeBoost,
          category: 'alarm', // Critical for Samsung/Android volume streams
        });
      } catch (e) {
        console.warn("Native TTS error:", e);
      }
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = settings.volumeBoost;
        utterance.lang = settings.voiceGender === 'female' ? 'en-GB' : 'en-US';
        utterance.rate = settings.voiceProfile === 'strict' ? 1.15 : 1.0;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [settings.voiceGender, settings.voiceProfile, settings.volumeBoost, isNative]);

  // RECURSIVE ALARM VOICE LOOP
  useEffect(() => {
    if (isAlarmActive && activeAlarmMessage && settings.voiceEnabled) {
      // First speak
      speak(activeAlarmMessage);

      const runLoop = () => {
        if (voiceLoopRef.current) clearTimeout(voiceLoopRef.current);
        voiceLoopRef.current = setTimeout(() => {
          if (isAlarmActive) {
            speak(activeAlarmMessage);
            runLoop(); // Recursive for stability
          }
        }, 12000); // 12-second interval for "Alarm" feel
      };
      runLoop();

      // AUTO-STOP SAFETY (5 MINUTES)
      if (safetyTimeoutRef.current) clearTimeout(safetyTimeoutRef.current);
      safetyTimeoutRef.current = setTimeout(() => {
        dismissAlarm();
      }, 300000);

    } else {
      if (voiceLoopRef.current) clearTimeout(voiceLoopRef.current);
      if (safetyTimeoutRef.current) clearTimeout(safetyTimeoutRef.current);
      stopAllAudio();
    }

    return () => {
      if (voiceLoopRef.current) clearTimeout(voiceLoopRef.current);
      if (safetyTimeoutRef.current) clearTimeout(safetyTimeoutRef.current);
    };
  }, [isAlarmActive, activeAlarmMessage, speak, stopAllAudio, settings.voiceEnabled, dismissAlarm]);

  // NATIVE BACKGROUND LISTENERS
  useEffect(() => {
    if (!isNative) return;

    let receivedListener: any;
    let performedListener: any;

    const setupListeners = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALARM_ACTIONS_FINAL',
          actions: [
            { id: 'stop', title: 'STOP', destructive: true },
            { id: 'snooze', title: 'SNOOZE (5m)' }
          ]
        }]
      });

      receivedListener = await LocalNotifications.addListener('localNotificationReceived', (notification) => {
        const type = notification.id === 1001 ? 'sedentary' : notification.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, notification.body || "Pulse Alert");
      });

      performedListener = await LocalNotifications.addListener('localNotificationActionPerformed', async (action) => {
        const type = action.notification.id === 1001 ? 'sedentary' : action.notification.id === 1002 ? 'water' : 'task';
        
        if (action.actionId === 'stop') {
          dismissAlarm();
        } else if (action.actionId === 'snooze') {
          snoozeAlarm();
          // Reschedule exactly 5 mins later
          const context = action.notification.body || undefined;
          scheduleAlert(type as any, context, 300);
        } else {
          // Default click triggers alarm UI
          triggerAlarm(type as any, action.notification.body || "Pulse Alert");
        }
      });
    };

    setupListeners();

    return () => {
      if (receivedListener) receivedListener.remove();
      if (performedListener) performedListener.remove();
    };
  }, [isNative, triggerAlarm, dismissAlarm, snoozeAlarm]);

  const scheduleAlert = useCallback(async (type: PulseType, context?: string, delaySeconds: number = 0) => {
    if (typeof window === 'undefined') return;

    const message = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Pulse: Task Due" : type === 'water' ? "Pulse: Hydration" : "Pulse: Movement";
    const notificationId = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 900000) + 1003;

    if (delaySeconds === 0) {
      toast({ title, description: message });
      triggerAlarm(type, message);
    }

    if (!isNative) {
      if (delaySeconds > 0) {
        setTimeout(() => {
          toast({ title, description: message });
          triggerAlarm(type, message);
        }, delaySeconds * 1000);
      }
      return;
    }

    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // Clear previous exact pulse to avoid overlap/spam
      await LocalNotifications.cancel({ notifications: [{ id: notificationId }] });

      if (delaySeconds >= 0) {
        await LocalNotifications.schedule({
          notifications: [{
            title,
            body: message,
            id: notificationId,
            schedule: delaySeconds > 0 ? { 
              at: new Date(Date.now() + delaySeconds * 1000), 
              allowWhileIdle: true 
            } : undefined,
            sound: 'beep.wav', // Basic trigger sound
            importance: 5, // Priority (Android)
            actionTypeId: 'PULSE_ALARM_ACTIONS_FINAL'
          }]
        });
      }
    } catch (e) {
      console.error("Native scheduling error:", e);
    }
  }, [triggerAlarm, settings.personality, toast, isNative]);

  const cancelNotification = useCallback(async (id: number) => {
    if (!isNative) return;
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      await LocalNotifications.cancel({ notifications: [{ id }] });
    } catch (e) {}
  }, [isNative]);

  return { triggerAlert: scheduleAlert, cancelNotification, speak, dismissAlarm, snoozeAlarm };
}
