
"use client";

import { useCallback } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';

export function usePulseAlerts() {
  const { settings } = useAppStore();
  const { toast } = useToast();

  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined') return;

    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.speak({
          text,
          lang: settings.voiceGender === 'female' ? 'en-GB' : 'en-US',
          rate: 1.0,
          volume: settings.volumeBoost,
          category: 'ambient',
        });
      } catch (e) {
        console.warn("Native TTS error:", e);
      }
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = settings.volumeBoost;
      window.speechSynthesis.speak(utterance);
    } else {
      toast({ title: "Pulse Voice", description: text });
    }
  }, [settings, isNative, toast]);

  const cancelAllNotifications = useCallback(async () => {
    if (typeof window === 'undefined' || !isNative) return;
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length > 0) {
        await LocalNotifications.cancel(pending);
      }
    } catch (e) { 
      console.warn("Notification cancel error:", e); 
    }
  }, [isNative]);

  const triggerAlert = useCallback(async (type: 'sedentary' | 'water' | 'task', context?: string, delaySeconds: number = 0) => {
    if (typeof window === 'undefined') return;

    let message = "";
    let title = "Pulse Alert";

    switch (type) {
      case 'sedentary': message = "Time to move! Stop sitting like a potato."; break;
      case 'water': message = "Hydrate now! Time for a glass of water."; break;
      case 'task': 
        message = `Reminder: ${context || "Pending task"}.`;
        title = "Task Pulse";
        break;
    }

    if (delaySeconds === 0) {
      toast({ title, description: message });
      speak(message);
    }

    if (!isNative) {
      if (delaySeconds > 0) {
        setTimeout(() => {
          toast({ title, description: message });
          speak(message);
        }, delaySeconds * 1000);
      }
      return;
    }

    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      const hasPerms = await LocalNotifications.checkPermissions();
      
      if (hasPerms.display !== 'granted') {
        await LocalNotifications.requestPermissions();
      }

      const id = Math.floor(Math.random() * 1000000);
      await LocalNotifications.schedule({
        notifications: [{
          title,
          body: message,
          id,
          schedule: delaySeconds > 0 ? { 
            at: new Date(Date.now() + delaySeconds * 1000), 
            allowWhileIdle: true 
          } : undefined,
          sound: 'beep.wav',
          importance: 5,
        }]
      });
    } catch (e) {
      console.error("Native notification error:", e);
    }
  }, [speak, toast, isNative]);

  return { triggerAlert, speak, cancelAllNotifications };
}
