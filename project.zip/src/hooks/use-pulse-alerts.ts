
"use client";

import { useCallback, useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, triggerAlarm, dismissAlarm, snoozeAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();
  const loopRef = useRef<NodeJS.Timeout | null>(null);

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined' || !text || !settings.voiceEnabled) return;
    
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        
        // Stop any current speech before starting a new one to prevent overlaps/truncation
        await TextToSpeech.stop();
        
        const voices = await TextToSpeech.getSupportedVoices();
        
        // Prioritize High-Quality/Neural voices
        const preferred = voices.voices.find(v => 
          v.name.toLowerCase().includes('google') || 
          v.name.toLowerCase().includes('enhanced') || 
          v.name.toLowerCase().includes('neural') ||
          v.name.toLowerCase().includes('samsung')
        );

        // Lang mapping based on profile
        let lang = 'en-US';
        if (settings.voiceProfile === 'natural') lang = 'en-GB';
        if (settings.voiceProfile === 'strict') lang = 'en-AU';

        await TextToSpeech.speak({
          text,
          lang,
          rate: 0.9,
          pitch: 1.0,
          volume: settings.volumeBoost,
          voice: preferred?.name,
          category: 'alarm' // USES ALARM CHANNEL FOR MAX VOLUME
        });
      } catch (e) {
        console.error("TTS Error:", e);
      }
    } else if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.volume = settings.volumeBoost;
      window.speechSynthesis.speak(utterance);
    }
  }, [settings, isNative]);

  const stopSpeak = useCallback(async () => {
    if (typeof window === 'undefined') return;
    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.stop();
      } catch (e) {}
    } else {
      window.speechSynthesis.cancel();
    }
  }, [isNative]);

  // RECURSIVE ALARM LOOP (MINIMAL GAP)
  useEffect(() => {
    let active = true;

    if (isAlarmActive && activeAlarmMessage) {
      const run = async () => {
        if (!active || !isAlarmActive) return;
        
        // Wait for speech to finish completely
        await speak(activeAlarmMessage);
        
        // Wait exactly 1 second before repeating if still active
        if (active && isAlarmActive) {
          loopRef.current = setTimeout(run, 1000);
        }
      };
      
      run();

      // 5-minute safety cutoff for ignored alarms
      const safetyTimeout = setTimeout(() => {
        if (isAlarmActive) dismissAlarm();
      }, 300000);

      return () => {
        active = false;
        if (loopRef.current) clearTimeout(loopRef.current);
        clearTimeout(safetyTimeout);
        stopSpeak();
      };
    } else {
      active = false;
      if (loopRef.current) clearTimeout(loopRef.current);
      stopSpeak();
    }
  }, [isAlarmActive, activeAlarmMessage, speak, stopSpeak, dismissAlarm]);

  // NATIVE BACKGROUND LISTENERS
  useEffect(() => {
    if (!isNative) return;
    let r: any, p: any;
    
    const setup = async () => {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      await LocalNotifications.registerActionTypes({
        types: [{
          id: 'PULSE_ALARM_ACTION',
          actions: [
            { id: 'stop', title: 'STOP ALARM', destructive: true },
            { id: 'snooze', title: 'SNOOZE (5M)' }
          ]
        }]
      });

      r = await LocalNotifications.addListener('localNotificationReceived', (n) => {
        const type = n.id === 1001 ? 'sedentary' : n.id === 1002 ? 'water' : 'task';
        triggerAlarm(type as any, n.body || "Pulse Alert");
      });

      p = await LocalNotifications.addListener('localNotificationActionPerformed', (a) => {
        if (a.actionId === 'stop') {
          dismissAlarm();
        } else if (a.actionId === 'snooze') {
          const type = a.notification.id === 1001 ? 'sedentary' : a.notification.id === 1002 ? 'water' : 'task';
          snoozeAlarm(type as any, a.notification.body || "");
        } else {
          const type = a.notification.id === 1001 ? 'sedentary' : a.notification.id === 1002 ? 'water' : 'task';
          triggerAlarm(type as any, a.notification.body || "Pulse Alert");
        }
      });
    };
    
    setup();
    return () => { if (r) r.remove(); if (p) p.remove(); };
  }, [isNative, triggerAlarm, dismissAlarm, snoozeAlarm]);

  const scheduleNative = useCallback(async (type: PulseType, context?: string, delay: number = 0) => {
    const msg = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Water Pulse" : "Move Pulse";
    const id = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 900000) + 1003;

    if (isNative) {
      try {
        const { LocalNotifications } = await import('@capacitor/local-notifications');
        
        await LocalNotifications.cancel({ notifications: [{ id }] });
        
        const baseTime = Date.now() + (delay * 1000);
        
        // Schedule a repeating sequence (Native OS doesn't support 1s loop, so we schedule multiple triggers)
        const notifications = [];
        for (let i = 0; i < 5; i++) {
          notifications.push({
            title,
            body: msg,
            id: i === 0 ? id : id + (i * 10000),
            schedule: { at: new Date(baseTime + (i * 10000)), allowWhileIdle: true },
            sound: 'beep.wav',
            importance: 5,
            ongoing: true,
            actionTypeId: 'PULSE_ALARM_ACTION'
          });
        }

        await LocalNotifications.schedule({ notifications });
      } catch (e) {
        console.error("Scheduling Error:", e);
      }
    } else if (delay > 0) {
      setTimeout(() => triggerAlarm(type, msg), delay * 1000);
    } else {
      triggerAlarm(type, msg);
    }
    
    if (delay === 0) toast({ title, description: msg });
  }, [settings.personality, isNative, triggerAlarm, toast]);

  const cancelNative = useCallback(async (id: number) => {
    if (!isNative) return;
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      const idsToCancel = [id, id + 10000, id + 20000, id + 30000, id + 40000];
      await LocalNotifications.cancel({ notifications: idsToCancel.map(i => ({ id: i })) });
    } catch (e) {}
  }, [isNative]);

  return { triggerAlert: scheduleNative, cancelNotification: cancelNative, speak, dismissAlarm };
}
