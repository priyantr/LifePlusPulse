
"use client";

import { useCallback, useRef, useEffect } from "react";
import { useAppStore } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { Capacitor } from '@capacitor/core';
import { getRandomMessage, PulseType } from "@/lib/personality";

export function usePulseAlerts() {
  const { settings, isAlarmActive, activeAlarmMessage, alarmStartedAt, triggerAlarm, dismissAlarm } = useAppStore();
  const { toast } = useToast();
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();

  const speak = useCallback(async (text: string) => {
    if (typeof window === 'undefined') return;

    if (isNative) {
      try {
        const { TextToSpeech } = await import('@capacitor-community/text-to-speech');
        await TextToSpeech.speak({
          text,
          lang: settings.voiceGender === 'female' ? 'en-GB' : 'en-US',
          rate: 1.0,
          volume: settings.volumeBoost,
          category: 'ambient',
        });
      } catch (e) {
        console.warn("Native TTS error:", e);
      }
    } else {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.volume = settings.volumeBoost;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [settings.voiceGender, settings.volumeBoost, isNative]);

  // Handle auto-dismiss after 60 seconds
  useEffect(() => {
    if (isAlarmActive && alarmStartedAt) {
      const checkTimeout = setInterval(() => {
        if (Date.now() - alarmStartedAt > 60000) {
          dismissAlarm();
        }
      }, 5000);
      return () => clearInterval(checkTimeout);
    }
  }, [isAlarmActive, alarmStartedAt, dismissAlarm]);

  // Handle repeating voice loop while alarm is active (Every 12 seconds)
  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    const runLoop = async () => {
      if (isAlarmActive && activeAlarmMessage && settings.voiceEnabled) {
        await speak(activeAlarmMessage);
        timeoutId = setTimeout(runLoop, 12000); // Repeat every 12 seconds
      }
    };

    if (isAlarmActive) {
      runLoop();
    } else {
      if (!isNative && typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    }

    return () => clearTimeout(timeoutId);
  }, [isAlarmActive, activeAlarmMessage, speak, settings.voiceEnabled, isNative]);

  const triggerAlert = useCallback(async (type: PulseType, context?: string, delaySeconds: number = 0) => {
    if (typeof window === 'undefined') return;

    const message = context || getRandomMessage(type, settings.personality);
    const title = type === 'task' ? "Task Pulse" : type === 'water' ? "Hydration Pulse" : "Move Pulse";

    // Immediate action (Foreground)
    if (delaySeconds === 0) {
      toast({ title, description: message });
      triggerAlarm(type, message);
    }

    if (!isNative) {
      if (delaySeconds > 0) {
        setTimeout(() => {
          toast({ title, description: message });
          triggerAlarm(type, message);
        }, delaySeconds * 1000);
      }
      return;
    }

    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      
      // Use consistent IDs per type to prevent duplicates
      const id = type === 'sedentary' ? 1001 : type === 'water' ? 1002 : Math.floor(Math.random() * 1000000);
      
      // Cancel any existing notification for this type before scheduling new one
      await LocalNotifications.cancel({ notifications: [{ id }] });

      await LocalNotifications.schedule({
        notifications: [{
          title,
          body: message,
          id,
          schedule: delaySeconds > 0 ? { 
            at: new Date(Date.now() + delaySeconds * 1000), 
            allowWhileIdle: true 
          } : undefined,
          sound: 'beep.wav',
          importance: 5,
        }]
      });
    } catch (e) {
      console.error("Native notification error:", e);
    }
  }, [triggerAlarm, settings.personality, toast, isNative]);

  return { triggerAlert, speak, dismissAlarm };
}
