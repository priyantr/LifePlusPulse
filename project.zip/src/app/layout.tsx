
import type {Metadata} from 'next';
import './globals.css';
import {Toaster} from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: 'Life+ Pulse | Advanced Vitality Management',
  description: 'Precision health monitoring and lifestyle optimization dashboard.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased overflow-x-hidden min-h-screen">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
