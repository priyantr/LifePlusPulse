
"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { AppStoreProvider, useAppStore } from "@/lib/app-store";
import { Dashboard } from "@/components/dashboard/Dashboard";
import { Navigation } from "@/components/layout/Navigation";
import { Button } from "@/components/ui/button";
import { Bell, X, Clock } from "lucide-react";
import { usePulseAlerts } from "@/hooks/use-pulse-alerts";
import { Capacitor } from "@capacitor/core";

const MoveTab = dynamic(() => import("@/components/tabs/MoveTab").then(mod => mod.MoveTab), { ssr: false });
const WaterTab = dynamic(() => import("@/components/tabs/WaterTab").then(mod => mod.WaterTab), { ssr: false });
const TasksTab = dynamic(() => import("@/components/tabs/TasksTab").then(mod => mod.TasksTab), { ssr: false });
const SettingsTab = dynamic(() => import("@/components/tabs/SettingsTab").then(mod => mod.SettingsTab), { ssr: false });

function AlarmOverlay() {
  const { isAlarmActive, activeAlarmMessage, activeAlarmType, dismissAlarm, snoozeAlarm } = useAppStore();

  if (!isAlarmActive) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex flex-col items-center justify-center p-8 animate-in fade-in zoom-in">
      <div className="w-full max-w-md bento-card border-primary/50 flex flex-col items-center text-center gap-6 py-12">
        <div className="p-6 rounded-full bg-primary/20 text-primary animate-pulse">
          <Bell className="h-12 w-12" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-headline font-bold tracking-tighter uppercase text-primary leading-none">Pulse Alert</h2>
          <p className="text-xl text-foreground font-medium italic px-4 mt-4">"{activeAlarmMessage || 'Time to check your pulse!'}"</p>
        </div>
        <div className="w-full flex flex-col gap-3 mt-4">
          <Button 
            size="lg" 
            onClick={() => dismissAlarm()}
            className="w-full h-20 rounded-3xl text-2xl font-bold bg-primary hover:bg-primary/90 shadow-[0_0_30px_rgba(var(--primary),0.4)]"
          >
            <X className="mr-2 h-6 w-6" /> STOP ALARM
          </Button>
          <Button 
            variant="outline"
            size="lg" 
            onClick={() => snoozeAlarm(activeAlarmType as any, activeAlarmMessage)}
            className="w-full h-14 rounded-2xl text-lg font-bold border-2"
          >
            <Clock className="mr-2 h-5 w-5" /> SNOOZE 5 MINS
          </Button>
        </div>
      </div>
    </div>
  );
}

function MainContent() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "move" | "water" | "tasks" | "settings">("dashboard");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    if (Capacitor.isNativePlatform()) {
      import('@capacitor/app').then(({ App }) => {
        App.addListener('backButton', () => {
          // Minimize instead of close to keep high-priority voice loops alive
          App.minimizeApp();
        });
      });
    }
  }, []);

  if (!mounted) return null;

  return (
    <main className="pb-40 pt-6 px-4 max-w-2xl mx-auto min-h-screen bg-background relative">
      <header className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-headline font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent tracking-tighter leading-none">
            LIFE+ PULSE
          </h1>
          <p className="text-muted-foreground text-[10px] font-bold uppercase tracking-widest opacity-70 mt-1">
            Native Health Alarm
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
          <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Engine Active</span>
        </div>
      </header>

      <div className="transition-all duration-300">
        {activeTab === "dashboard" && <Dashboard onNavigate={setActiveTab} />}
        {activeTab === "move" && <MoveTab />}
        {activeTab === "water" && <WaterTab />}
        {activeTab === "tasks" && <TasksTab />}
        {activeTab === "settings" && <SettingsTab />}
      </div>

      <AlarmOverlay />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </main>
  );
}

export default function Home() {
  return (
    <AppStoreProvider>
      <MainContent />
    </AppStoreProvider>
  );
}
