
"use client";

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { AppStoreProvider } from "@/lib/app-store";
import { Dashboard } from "@/components/dashboard/Dashboard";
import { Navigation } from "@/components/layout/Navigation";

// Dynamically import tab components with SSR disabled to prevent Capacitor plugin evaluation on server
const MoveTab = dynamic(() => import("@/components/tabs/MoveTab").then(mod => mod.MoveTab), { ssr: false });
const WaterTab = dynamic(() => import("@/components/tabs/WaterTab").then(mod => mod.WaterTab), { ssr: false });
const TasksTab = dynamic(() => import("@/components/tabs/TasksTab").then(mod => mod.TasksTab), { ssr: false });
const SettingsTab = dynamic(() => import("@/components/tabs/SettingsTab").then(mod => mod.SettingsTab), { ssr: false });

export default function Home() {
  const [activeTab, setActiveTab] = useState<"dashboard" | "move" | "water" | "tasks" | "settings">("dashboard");

  // Prevent back button from closing app on Android - Client side only
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const handlePopState = (e: PopStateEvent) => {
      if (activeTab !== "dashboard") {
        e.preventDefault();
        setActiveTab("dashboard");
        window.history.pushState(null, "", "");
      }
    };

    window.history.pushState(null, "", "");
    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, [activeTab]);

  return (
    <AppStoreProvider>
      <main className="pb-24 pt-6 px-4 max-w-2xl mx-auto min-h-screen bg-background">
        <header className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-headline font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent tracking-tighter">
              LIFE+ PULSE
            </h1>
            <p className="text-muted-foreground text-[10px] font-bold uppercase tracking-widest opacity-70">
              Biometric Life Optimization
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-primary animate-pulse shadow-[0_0_10px_rgba(var(--primary),0.5)]" />
            <span className="text-[10px] font-bold text-muted-foreground">LIVE</span>
          </div>
        </header>

        {activeTab === "dashboard" && <Dashboard onNavigate={setActiveTab} />}
        {activeTab === "move" && <MoveTab />}
        {activeTab === "water" && <WaterTab />}
        {activeTab === "tasks" && <TasksTab />}
        {activeTab === "settings" && <SettingsTab />}

        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      </main>
    </AppStoreProvider>
  );
}
