
export type Personality = 'funny' | 'sarcastic' | 'motivational' | 'calm';
export type PulseType = 'sedentary' | 'water' | 'task';

const messages: Record<PulseType, Record<Personality, string[]>> = {
  sedentary: {
    funny: [
      "Move. Your chair thinks you live here.",
      "Stop sitting like a potato 🥔",
      "Your glutes are starting to merge with the cushion.",
      "Time to move! Your fitness tracker is getting bored."
    ],
    sarcastic: [
      "Oh, another hour of sitting? How original.",
      "You're doing a great job pretending to be a statue.",
      "Is your goal to become one with the furniture?",
      "Keep sitting. I'm sure your legs will remember how to work eventually."
    ],
    motivational: [
      "Time to activate! Your body thrives on movement.",
      "A quick stretch doubles your energy.",
      "Rise and shine, even if just for a short walk.",
      "Small moves lead to big health gains."
    ],
    calm: [
      "Gently stand up and take a deep breath.",
      "Release the tension in your shoulders.",
      "A soft movement for a peaceful mind.",
      "Honor your body with a moment of activity."
    ]
  },
  water: {
    funny: [
      "Hydrate now, human cactus 🌵",
      "Drink water before your organs file a complaint.",
      "Your brain is 75% water, don't let it become a raisin.",
      "Water! Because you can't survive on coffee and spite alone."
    ],
    sarcastic: [
      "Water. It's that clear stuff you usually avoid.",
      "Breaking news: You're actually thirsty.",
      "Your plants get more water than you do. Think about that.",
      "Drink some water. Your skin looks like a map of the Sahara."
    ],
    motivational: [
      "Fuel your cells. One glass for clarity.",
      "Hydration is the foundation of peak performance.",
      "Drink to your health and vitality.",
      "Success starts with a hydrated mind."
    ],
    calm: [
      "Sip slowly and feel the renewal.",
      "Water flows, and so does your peace.",
      "A quiet moment for a refreshing drink.",
      "Nourish yourself with the gift of water."
    ]
  },
  task: {
    funny: [
      "Look at you being productive 😏",
      "Task killed! You're a legend.",
      "One step closer to world domination.",
      "You did a thing! Treat yourself."
    ],
    sarcastic: [
      "Wow, you actually did it. I'm shocked.",
      "Gold star for doing what you were supposed to do.",
      "Impressive. Don't let it go to your head.",
      "Look who's all grown up and finishing tasks."
    ],
    motivational: [
      "Excellent work! Consistency is key.",
      "Victory! Keep that momentum going.",
      "You are unstoppable today.",
      "Great job. Every task done is a win."
    ],
    calm: [
      "Well done. Take a moment to appreciate the progress.",
      "Completion brings peace.",
      "A task finished, a mind cleared.",
      "Quiet satisfaction in a job well done."
    ]
  }
};

export function getRandomMessage(type: PulseType, personality: Personality): string {
  const list = messages[type][personality];
  return list[Math.floor(Math.random() * list.length)];
}
