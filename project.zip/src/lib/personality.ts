
export type Personality = 'funny' | 'sarcastic' | 'motivational' | 'calm';
export type PulseType = 'sedentary' | 'water' | 'task';

const messages: Record<PulseType, Record<Personality, string[]>> = {
  sedentary: {
    funny: [
      "Move. Your chair thinks you live here now.",
      "Stop sitting like a potato. Your glutes are vanishing.",
      "Get up! Gravity is doing too much work on your spine.",
      "Time to move! Your fitness tracker is dying of boredom.",
      "Stand up! Your chair is starting to merge with your body."
    ],
    sarcastic: [
      "Oh, another hour of sitting? How original and exciting.",
      "You're doing a great job pretending to be a museum statue.",
      "Is your goal to become one with the furniture today?",
      "Keep sitting. I'm sure your legs will remember how to work eventually.",
      "Your chair misses you already? Get up and move anyway."
    ],
    motivational: [
      "Time to activate! Your body thrives on regular movement.",
      "A quick stretch now doubles your energy for later.",
      "Rise and shine, even if just for a short walk around.",
      "Small moves lead to massive health gains over time.",
      "You have the power to move. Use it right now."
    ],
    calm: [
      "Gently stand up and take a long, deep breath.",
      "Release the tension in your shoulders and neck.",
      "A soft movement for a peaceful and focused mind.",
      "Honor your body with a brief moment of activity.",
      "Slowly rise and find your physical balance."
    ]
  },
  water: {
    funny: [
      "Hydrate now, human cactus. Your skin is drying up.",
      "Drink water before your organs file a formal complaint.",
      "Your brain is 75% water, don't let it become a raisin.",
      "Water! Because you can't survive on coffee and spite alone.",
      "Gulp gulp! Your cells are literally begging for a pool party."
    ],
    sarcastic: [
      "Water. It's that clear stuff you usually avoid like the plague.",
      "Breaking news: You're actually thirsty. Drink something clear.",
      "Your plants get more water than you do. Think about that.",
      "Drink some water. Your skin looks like a map of the Sahara.",
      "I know water is boring, but being a raisin is even worse."
    ],
    motivational: [
      "Fuel your cells. One glass for instant mental clarity.",
      "Hydration is the foundation of peak daily performance.",
      "Drink to your long-term health and physical vitality.",
      "Success starts with a hydrated and sharp mind.",
      "Clear water for a clear vision of your goals."
    ],
    calm: [
      "Sip slowly and feel the renewal in every cell.",
      "Water flows, and so does your inner peace.",
      "A quiet moment for a refreshing and life-giving drink.",
      "Nourish yourself with the essential gift of water.",
      "Flow like water, peaceful, refreshing, and persistent."
    ]
  },
  task: {
    funny: [
      "Look at you being productive! I'm genuinely impressed.",
      "Task killed! You're a productivity legend in the making.",
      "One step closer to total world domination. Good job.",
      "You did a thing! Treat yourself to a tiny celebration.",
      "High five! You actually finished it. I knew you could."
    ],
    sarcastic: [
      "Wow, you actually did it. I'm shocked and amazed.",
      "Gold star for doing what you were supposed to do anyway.",
      "Impressive. Don't let this minor victory go to your head.",
      "Look who's all grown up and finally finishing tasks.",
      "You finished a task. Should I call the local press?"
    ],
    motivational: [
      "Excellent work! Consistency is the real key to success.",
      "Victory! Keep that powerful momentum going all day.",
      "You are absolutely unstoppable today. Keep it up.",
      "Great job. Every task done is a major win for you.",
      "Peak productivity achieved. Keep going and stay focused."
    ],
    calm: [
      "Well done. Take a moment to appreciate your progress.",
      "Completion brings a sense of deep inner peace.",
      "A task finished, a mind cleared for the next step.",
      "Quiet satisfaction in a job well and truly done.",
      "One step complete. Breathe deeply and reflect on it."
    ]
  }
};

export function getRandomMessage(type: PulseType, personality: Personality): string {
  const list = messages[type][personality];
  return list[Math.floor(Math.random() * list.length)];
}
