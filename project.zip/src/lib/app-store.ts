
"use client";

import { useState, createContext, useContext, ReactNode, createElement, useEffect } from "react";
import { Personality } from "./personality";

export interface Task {
  id: string;
  title: string;
  time: string;
  completed: boolean;
  repeat: "none" | "daily";
}

interface AppSettings {
  voiceEnabled: boolean;
  voiceGender: "male" | "female";
  volumeBoost: number;
  personality: Personality;
}

interface AppState {
  sedentaryInterval: number;
  isMoveTimerActive: boolean;
  isMoveTimerPaused: boolean;
  timeLeft: number;
  moveTargetTime: number | null;
  
  waterGoal: number;
  waterIntake: number;
  waterInterval: number;
  isWaterTimerActive: boolean;
  isWaterTimerPaused: boolean;
  waterTimeLeft: number;
  waterTargetTime: number | null;

  tasks: Task[];
  settings: AppSettings;
  
  isAlarmActive: boolean;
  activeAlarmMessage: string;
  activeAlarmType: 'sedentary' | 'water' | 'task' | null;
  alarmStartedAt: number | null;

  setSedentaryInterval: (val: number) => void;
  startMoveTimer: () => void;
  pauseMoveTimer: () => void;
  resumeMoveTimer: () => void;
  resetMoveTimer: () => void;
  stopMoveTimer: () => void;
  
  updateWaterIntake: (delta: number) => void;
  setWaterInterval: (val: number) => void;
  startWaterTimer: () => void;
  pauseWaterTimer: () => void;
  resumeWaterTimer: () => void;
  resetWaterTimer: () => void;
  stopWaterTimer: () => void;

  addTask: (task: Omit<Task, 'id' | 'completed'>) => void;
  removeTask: (id: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  
  triggerAlarm: (type: 'sedentary' | 'water' | 'task', message: string) => void;
  dismissAlarm: () => void;
}

const AppStoreContext = createContext<AppState | null>(null);

export function AppStoreProvider({ children }: { children: ReactNode }) {
  const [sedentaryInterval, setSedentaryIntervalState] = useState(45);
  const [isMoveTimerActive, setIsMoveTimerActive] = useState(false);
  const [isMoveTimerPaused, setIsMoveTimerPaused] = useState(false);
  const [timeLeft, setTimeLeftState] = useState(45 * 60);
  const [moveTargetTime, setMoveTargetTime] = useState<number | null>(null);

  const [waterGoal] = useState(8);
  const [waterIntake, setWaterIntake] = useState(0);
  const [waterInterval, setWaterIntervalState] = useState(60);
  const [isWaterTimerActive, setIsWaterTimerActive] = useState(false);
  const [isWaterTimerPaused, setIsWaterTimerPaused] = useState(false);
  const [waterTimeLeft, setWaterTimeLeftState] = useState(60 * 60);
  const [waterTargetTime, setWaterTargetTime] = useState<number | null>(null);

  const [tasks, setTasks] = useState<Task[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    voiceEnabled: true,
    voiceGender: "female",
    volumeBoost: 1,
    personality: "funny"
  });

  const [isAlarmActive, setIsAlarmActive] = useState(false);
  const [activeAlarmMessage, setActiveAlarmMessage] = useState("");
  const [activeAlarmType, setActiveAlarmType] = useState<'sedentary' | 'water' | 'task' | null>(null);
  const [alarmStartedAt, setAlarmStartedAt] = useState<number | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      
      if (isMoveTimerActive && !isMoveTimerPaused && moveTargetTime) {
        const remaining = Math.max(0, Math.floor((moveTargetTime - now) / 1000));
        setTimeLeftState(remaining);
      }

      if (isWaterTimerActive && !isWaterTimerPaused && waterTargetTime) {
        const remaining = Math.max(0, Math.floor((waterTargetTime - now) / 1000));
        setWaterTimeLeftState(remaining);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isMoveTimerActive, isMoveTimerPaused, moveTargetTime, isWaterTimerActive, isWaterTimerPaused, waterTargetTime]);

  const value: AppState = {
    sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, timeLeft, moveTargetTime,
    waterGoal, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTimeLeft, waterTargetTime,
    tasks, settings, isAlarmActive, activeAlarmMessage, activeAlarmType, alarmStartedAt,
    setSedentaryInterval: (val) => {
      setSedentaryIntervalState(val);
      if (!isMoveTimerActive) setTimeLeftState(val * 60);
    },
    startMoveTimer: () => {
      const target = Date.now() + sedentaryInterval * 60 * 1000;
      setMoveTargetTime(target);
      setIsMoveTimerActive(true);
      setIsMoveTimerPaused(false);
      setTimeLeftState(sedentaryInterval * 60);
    },
    pauseMoveTimer: () => setIsMoveTimerPaused(true),
    resumeMoveTimer: () => {
      setMoveTargetTime(Date.now() + timeLeft * 1000);
      setIsMoveTimerPaused(false);
    },
    resetMoveTimer: () => {
      const target = Date.now() + sedentaryInterval * 60 * 1000;
      setMoveTargetTime(target);
      setTimeLeftState(sedentaryInterval * 60);
      setIsMoveTimerPaused(false);
    },
    stopMoveTimer: () => {
      setIsMoveTimerActive(false);
      setIsMoveTimerPaused(false);
      setMoveTargetTime(null);
      setTimeLeftState(sedentaryInterval * 60);
    },
    updateWaterIntake: (delta) => setWaterIntake(prev => Math.max(0, prev + delta)),
    setWaterInterval: (val) => {
      setWaterIntervalState(val);
      if (!isWaterTimerActive) setWaterTimeLeftState(val * 60);
    },
    startWaterTimer: () => {
      const target = Date.now() + waterInterval * 60 * 1000;
      setWaterTargetTime(target);
      setIsWaterTimerActive(true);
      setIsWaterTimerPaused(false);
      setWaterTimeLeftState(waterInterval * 60);
    },
    pauseWaterTimer: () => setIsWaterTimerPaused(true),
    resumeWaterTimer: () => {
      setWaterTargetTime(Date.now() + waterTimeLeft * 1000);
      setIsWaterTimerPaused(false);
    },
    resetWaterTimer: () => {
      const target = Date.now() + waterInterval * 60 * 1000;
      setWaterTargetTime(target);
      setWaterTimeLeftState(waterInterval * 60);
      setIsWaterTimerPaused(false);
    },
    stopWaterTimer: () => {
      setIsWaterTimerActive(false);
      setIsWaterTimerPaused(false);
      setWaterTargetTime(null);
      setWaterTimeLeftState(waterInterval * 60);
    },
    addTask: (task) => setTasks(prev => [...prev, { ...task, id: Math.random().toString(36).substr(2, 9), completed: false }]),
    removeTask: (id) => setTasks(prev => prev.filter(t => t.id !== id)),
    updateSettings: (newS) => setSettings(prev => ({ ...prev, ...newS })),
    triggerAlarm: (type, message) => {
      // Ensure we don't spam state updates if already active with same message
      setIsAlarmActive(true);
      setActiveAlarmMessage(message);
      setActiveAlarmType(type);
      setAlarmStartedAt(Date.now());
    },
    dismissAlarm: () => {
      setIsAlarmActive(false);
      setActiveAlarmMessage("");
      setActiveAlarmType(null);
      setAlarmStartedAt(null);
    }
  };

  return createElement(AppStoreContext.Provider, { value }, children);
}

export function useAppStore() {
  const context = useContext(AppStoreContext);
  if (!context) throw new Error("useAppStore missing provider");
  return context;
}
