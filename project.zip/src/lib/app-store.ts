
"use client";

import { useState, createContext, useContext, ReactNode, createElement, useEffect } from "react";

export interface Task {
  id: string;
  title: string;
  time: string;
  completed: boolean;
  repeat: "none" | "daily";
}

interface AppSettings {
  voiceEnabled: boolean;
  voiceGender: "male" | "female";
  volumeBoost: number;
}

interface AppState {
  // Move Reminder
  sedentaryInterval: number;
  isMoveTimerActive: boolean;
  isMoveTimerPaused: boolean;
  timeLeft: number;
  moveTargetTime: number | null; // Timestamp for when the timer should end
  
  // Water Tracker & Reminder
  waterGoal: number;
  waterIntake: number;
  waterInterval: number;
  isWaterTimerActive: boolean;
  isWaterTimerPaused: boolean;
  waterTimeLeft: number;
  waterTargetTime: number | null;

  tasks: Task[];
  settings: AppSettings;

  // Actions
  setSedentaryInterval: (val: number) => void;
  startMoveTimer: () => void;
  pauseMoveTimer: () => void;
  resumeMoveTimer: () => void;
  resetMoveTimer: () => void;
  stopMoveTimer: () => void;
  setTimeLeft: (val: number | ((prev: number) => number)) => void;
  
  updateWaterIntake: (delta: number) => void;
  setWaterInterval: (val: number) => void;
  startWaterTimer: () => void;
  pauseWaterTimer: () => void;
  resumeWaterTimer: () => void;
  resetWaterTimer: () => void;
  stopWaterTimer: () => void;
  setWaterTimeLeft: (val: number | ((prev: number) => number)) => void;

  addTask: (task: Omit<Task, 'id' | 'completed'>) => void;
  removeTask: (id: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
}

const AppStoreContext = createContext<AppState | null>(null);

export function AppStoreProvider({ children }: { children: ReactNode }) {
  // Move State
  const [sedentaryInterval, setSedentaryIntervalState] = useState(45);
  const [isMoveTimerActive, setIsMoveTimerActive] = useState(false);
  const [isMoveTimerPaused, setIsMoveTimerPaused] = useState(false);
  const [timeLeft, setTimeLeftState] = useState(45 * 60);
  const [moveTargetTime, setMoveTargetTime] = useState<number | null>(null);

  // Water State
  const [waterGoal] = useState(8);
  const [waterIntake, setWaterIntake] = useState(0);
  const [waterInterval, setWaterIntervalState] = useState(60);
  const [isWaterTimerActive, setIsWaterTimerActive] = useState(false);
  const [isWaterTimerPaused, setIsWaterTimerPaused] = useState(false);
  const [waterTimeLeft, setWaterTimeLeftState] = useState(60 * 60);
  const [waterTargetTime, setWaterTargetTime] = useState<number | null>(null);

  const [tasks, setTasks] = useState<Task[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    voiceEnabled: true,
    voiceGender: "female",
    volumeBoost: 1,
  });

  // Load state on mount
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const saved = localStorage.getItem("pulse_native_v6");
    if (saved) {
      try {
        const p = JSON.parse(saved);
        if (p.sedentaryInterval) setSedentaryIntervalState(Number(p.sedentaryInterval));
        if (p.waterInterval) setWaterIntervalState(Number(p.waterInterval));
        if (p.waterIntake !== undefined) setWaterIntake(Number(p.waterIntake));
        if (p.tasks) setTasks(p.tasks);
        if (p.settings) setSettings(s => ({ ...s, ...p.settings }));
        
        // Restore active timers
        if (p.moveTargetTime) {
          setMoveTargetTime(p.moveTargetTime);
          setIsMoveTimerActive(true);
        }
        if (p.waterTargetTime) {
          setWaterTargetTime(p.waterTargetTime);
          setIsWaterTimerActive(true);
        }
      } catch (e) { console.warn("Store load error", e); }
    }
  }, []);

  // Save state on change
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const state = { 
      sedentaryInterval, 
      waterInterval, 
      waterIntake, 
      tasks, 
      settings,
      moveTargetTime,
      waterTargetTime
    };
    localStorage.setItem("pulse_native_v6", JSON.stringify(state));
  }, [sedentaryInterval, waterInterval, waterIntake, tasks, settings, moveTargetTime, waterTargetTime]);

  // Global Timer Sync (Survives minimize/lock)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      
      if (isMoveTimerActive && !isMoveTimerPaused && moveTargetTime) {
        const remaining = Math.max(0, Math.floor((moveTargetTime - now) / 1000));
        setTimeLeftState(remaining);
        if (remaining === 0) {
          // Reset target for next cycle
          setMoveTargetTime(now + sedentaryInterval * 60 * 1000);
        }
      }

      if (isWaterTimerActive && !isWaterTimerPaused && waterTargetTime) {
        const remaining = Math.max(0, Math.floor((waterTargetTime - now) / 1000));
        setWaterTimeLeftState(remaining);
        if (remaining === 0) {
          setWaterTargetTime(now + waterInterval * 60 * 1000);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isMoveTimerActive, isMoveTimerPaused, moveTargetTime, isWaterTimerActive, isWaterTimerPaused, waterTargetTime, sedentaryInterval, waterInterval]);

  const value: AppState = {
    sedentaryInterval,
    isMoveTimerActive,
    isMoveTimerPaused,
    timeLeft,
    moveTargetTime,
    waterGoal,
    waterIntake,
    waterInterval,
    isWaterTimerActive,
    isWaterTimerPaused,
    waterTimeLeft,
    waterTargetTime,
    tasks,
    settings,

    setSedentaryInterval: (val) => {
      const n = isNaN(val) ? 45 : Math.max(1, val);
      setSedentaryIntervalState(n);
      if (!isMoveTimerActive) setTimeLeftState(n * 60);
    },
    startMoveTimer: () => {
      const target = Date.now() + sedentaryInterval * 60 * 1000;
      setMoveTargetTime(target);
      setIsMoveTimerActive(true);
      setIsMoveTimerPaused(false);
      setTimeLeftState(sedentaryInterval * 60);
    },
    pauseMoveTimer: () => setIsMoveTimerPaused(true),
    resumeMoveTimer: () => {
      const target = Date.now() + timeLeft * 1000;
      setMoveTargetTime(target);
      setIsMoveTimerPaused(false);
    },
    resetMoveTimer: () => {
      const target = Date.now() + sedentaryInterval * 60 * 1000;
      setMoveTargetTime(target);
      setTimeLeftState(sedentaryInterval * 60);
    },
    stopMoveTimer: () => {
      setIsMoveTimerActive(false);
      setIsMoveTimerPaused(false);
      setMoveTargetTime(null);
      setTimeLeftState(sedentaryInterval * 60);
    },
    setTimeLeft: (val) => setTimeLeftState(prev => {
      const next = typeof val === 'function' ? val(prev) : val;
      return isNaN(next) ? sedentaryInterval * 60 : next;
    }),

    updateWaterIntake: (delta) => setWaterIntake(prev => Math.max(0, prev + Number(delta))),
    setWaterInterval: (val) => {
      const n = isNaN(val) ? 60 : Math.max(1, val);
      setWaterIntervalState(n);
      if (!isWaterTimerActive) setWaterTimeLeftState(n * 60);
    },
    startWaterTimer: () => {
      const target = Date.now() + waterInterval * 60 * 1000;
      setWaterTargetTime(target);
      setIsWaterTimerActive(true);
      setIsWaterTimerPaused(false);
      setWaterTimeLeftState(waterInterval * 60);
    },
    pauseWaterTimer: () => setIsWaterTimerPaused(true),
    resumeWaterTimer: () => {
      const target = Date.now() + waterTimeLeft * 1000;
      setWaterTargetTime(target);
      setIsWaterTimerPaused(false);
    },
    resetWaterTimer: () => {
      const target = Date.now() + waterInterval * 60 * 1000;
      setWaterTargetTime(target);
      setWaterTimeLeftState(waterInterval * 60);
    },
    stopWaterTimer: () => {
      setIsWaterTimerActive(false);
      setIsWaterTimerPaused(false);
      setWaterTargetTime(null);
      setWaterTimeLeftState(waterInterval * 60);
    },
    setWaterTimeLeft: (val) => setWaterTimeLeftState(prev => {
      const next = typeof val === 'function' ? val(prev) : val;
      return isNaN(next) ? waterInterval * 60 : next;
    }),

    addTask: (task) => setTasks(prev => [...prev, { ...task, id: Math.random().toString(36).substring(2, 11), completed: false }]),
    removeTask: (id) => setTasks(prev => prev.filter(t => t.id !== id)),
    updateSettings: (newS) => setSettings(prev => ({ ...prev, ...newS })),
  };

  return createElement(AppStoreContext.Provider, { value }, children);
}

export function useAppStore() {
  const context = useContext(AppStoreContext);
  if (!context) throw new Error("useAppStore missing provider");
  return context;
}
