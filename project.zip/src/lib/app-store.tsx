
"use client";

import { useState, createContext, useContext, ReactNode, useMemo, useCallback, useEffect } from "react";
import { Personality } from "./personality";

export interface Task {
  id: string;
  title: string;
  time: string;
  completed: boolean;
  repeat: "none" | "daily";
}

interface AppSettings {
  voiceEnabled: boolean;
  voiceGender: "male" | "female";
  voiceProfile: "natural" | "studio" | "funny" | "strict";
  volumeBoost: number;
  personality: Personality;
}

interface AppState {
  sedentaryInterval: number;
  isMoveTimerActive: boolean;
  isMoveTimerPaused: boolean;
  moveTargetTimestamp: number | null;
  timeLeft: number;
  
  waterGoal: number;
  waterIntake: number;
  waterInterval: number;
  isWaterTimerActive: boolean;
  isWaterTimerPaused: boolean;
  waterTargetTimestamp: number | null;
  waterTimeLeft: number;

  tasks: Task[];
  settings: AppSettings;
  
  isAlarmActive: boolean;
  activeAlarmMessage: string;
  activeAlarmType: 'sedentary' | 'water' | 'task' | null;

  setSedentaryInterval: (val: number) => void;
  startMoveTimer: () => void;
  stopMoveTimer: () => void;
  pauseMoveTimer: () => void;
  resumeMoveTimer: () => void;
  
  updateWaterIntake: (delta: number) => void;
  setWaterInterval: (val: number) => void;
  startWaterTimer: () => void;
  stopWaterTimer: () => void;
  pauseWaterTimer: () => void;
  resumeWaterTimer: () => void;

  addTask: (task: Omit<Task, 'id' | 'completed'>) => void;
  removeTask: (id: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  
  triggerAlarm: (type: 'sedentary' | 'water' | 'task', message: string) => void;
  dismissAlarm: () => void;
  snoozeAlarm: (type: 'sedentary' | 'water' | 'task', message: string) => void;
}

const AppStoreContext = createContext<AppState | null>(null);

export function AppStoreProvider({ children }: { children: ReactNode }) {
  const save = useCallback((key: string, val: any) => {
    if (typeof window !== 'undefined') {
      try { localStorage.setItem(`pulse_v15_${key}`, JSON.stringify(val)); } catch (e) {}
    }
  }, []);

  const load = useCallback((key: string, fallback: any) => {
    if (typeof window === 'undefined') return fallback;
    try {
      const item = localStorage.getItem(`pulse_v15_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch (e) { return fallback; }
  }, []);

  const [sedentaryInterval, setSedentaryIntervalState] = useState(() => load('sed_int', 45));
  const [isMoveTimerActive, setIsMoveTimerActive] = useState(() => load('sed_active', false));
  const [isMoveTimerPaused, setIsMoveTimerPaused] = useState(() => load('sed_paused', false));
  const [moveTargetTimestamp, setMoveTargetTimestamp] = useState<number | null>(() => load('sed_target', null));
  const [timeLeft, setTimeLeft] = useState(sedentaryInterval * 60);

  const [waterGoal] = useState(8);
  const [waterIntake, setWaterIntake] = useState(() => load('water_int', 0));
  const [waterInterval, setWaterIntervalState] = useState(() => load('water_int_val', 60));
  const [isWaterTimerActive, setIsWaterTimerActive] = useState(() => load('water_active', false));
  const [isWaterTimerPaused, setIsWaterTimerPaused] = useState(() => load('water_paused', false));
  const [waterTargetTimestamp, setWaterTargetTimestamp] = useState<number | null>(() => load('water_target', null));
  const [waterTimeLeft, setWaterTimeLeft] = useState(waterInterval * 60);

  const [tasks, setTasks] = useState<Task[]>(() => load('tasks', []));
  const [settings, setSettings] = useState<AppSettings>(() => load('settings', {
    voiceEnabled: true,
    voiceGender: "female",
    voiceProfile: "natural",
    volumeBoost: 1.0,
    personality: "funny"
  }));

  const [isAlarmActive, setIsAlarmActive] = useState(() => load('alarm_active', false));
  const [activeAlarmMessage, setActiveAlarmMessage] = useState(() => load('alarm_msg', ""));
  const [activeAlarmType, setActiveAlarmType] = useState<'sedentary' | 'water' | 'task' | null>(() => load('alarm_type', null));

  useEffect(() => {
    save('sed_int', sedentaryInterval);
    save('sed_active', isMoveTimerActive);
    save('sed_paused', isMoveTimerPaused);
    save('sed_target', moveTargetTimestamp);
    save('water_int', waterIntake);
    save('water_int_val', waterInterval);
    save('water_active', isWaterTimerActive);
    save('water_paused', isWaterTimerPaused);
    save('water_target', waterTargetTimestamp);
    save('tasks', tasks);
    save('settings', settings);
    save('alarm_active', isAlarmActive);
    save('alarm_msg', activeAlarmMessage);
    save('alarm_type', activeAlarmType);
  }, [sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, moveTargetTimestamp, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTargetTimestamp, tasks, settings, isAlarmActive, activeAlarmMessage, activeAlarmType, save]);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      
      if (isMoveTimerActive && !isMoveTimerPaused && moveTargetTimestamp) {
        const remaining = Math.max(0, Math.floor((moveTargetTimestamp - now) / 1000));
        setTimeLeft(remaining);
        if (remaining === 0 && !isAlarmActive) {
          setIsAlarmActive(true);
          setActiveAlarmType('sedentary');
        }
      }

      if (isWaterTimerActive && !isWaterTimerPaused && waterTargetTimestamp) {
        const remaining = Math.max(0, Math.floor((waterTargetTimestamp - now) / 1000));
        setWaterTimeLeft(remaining);
        if (remaining === 0 && !isAlarmActive) {
          setIsAlarmActive(true);
          setActiveAlarmType('water');
        }
      }
    }, 500);
    return () => clearInterval(interval);
  }, [isMoveTimerActive, isMoveTimerPaused, moveTargetTimestamp, isWaterTimerActive, isWaterTimerPaused, waterTargetTimestamp, isAlarmActive]);

  const setSedentaryInterval = useCallback((val: number) => {
    setSedentaryIntervalState(val);
    if (!isMoveTimerActive) setTimeLeft(val * 60);
  }, [isMoveTimerActive]);

  const startMoveTimer = useCallback(() => {
    const target = Date.now() + sedentaryInterval * 60 * 1000;
    setMoveTargetTimestamp(target);
    setIsMoveTimerActive(true);
    setIsMoveTimerPaused(false);
  }, [sedentaryInterval]);

  const stopMoveTimer = useCallback(() => {
    setIsMoveTimerActive(false);
    setIsMoveTimerPaused(false);
    setMoveTargetTimestamp(null);
  }, []);

  const pauseMoveTimer = useCallback(() => setIsMoveTimerPaused(true), []);
  const resumeMoveTimer = useCallback(() => {
    if (timeLeft > 0) {
      setMoveTargetTimestamp(Date.now() + timeLeft * 1000);
      setIsMoveTimerPaused(false);
    }
  }, [timeLeft]);

  const updateWaterIntake = useCallback((delta: number) => {
    setWaterIntake(prev => Math.max(0, prev + delta));
  }, []);

  const setWaterInterval = useCallback((val: number) => {
    setWaterIntervalState(val);
    if (!isWaterTimerActive) setWaterTimeLeft(val * 60);
  }, [isWaterTimerActive]);

  const startWaterTimer = useCallback(() => {
    const target = Date.now() + waterInterval * 60 * 1000;
    setWaterTargetTimestamp(target);
    setIsWaterTimerActive(true);
    setIsWaterTimerPaused(false);
  }, [waterInterval]);

  const stopWaterTimer = useCallback(() => {
    setIsWaterTimerActive(false);
    setIsWaterTimerPaused(false);
    setWaterTargetTimestamp(null);
  }, []);

  const pauseWaterTimer = useCallback(() => setIsWaterTimerPaused(true), []);
  const resumeWaterTimer = useCallback(() => {
    if (waterTimeLeft > 0) {
      setWaterTargetTimestamp(Date.now() + waterTimeLeft * 1000);
      setIsWaterTimerPaused(false);
    }
  }, [waterTimeLeft]);

  const addTask = useCallback((task: Omit<Task, 'id' | 'completed'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setTasks(prev => [...prev, { ...task, id, completed: false }]);
  }, []);

  const removeTask = useCallback((id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  }, []);

  const updateSettings = useCallback((newS: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newS }));
  }, []);

  const triggerAlarm = useCallback((type: 'sedentary' | 'water' | 'task', message: string) => {
    setActiveAlarmMessage(message);
    setActiveAlarmType(type);
    setIsAlarmActive(true);
  }, []);

  const dismissAlarm = useCallback(() => {
    setIsAlarmActive(false);
    setActiveAlarmMessage("");
    setActiveAlarmType(null);
    // Restart active intervals if they were silenced
    if (isMoveTimerActive) startMoveTimer();
    if (isWaterTimerActive) startWaterTimer();
  }, [isMoveTimerActive, isWaterTimerActive, startMoveTimer, startWaterTimer]);

  const snoozeAlarm = useCallback((type: 'sedentary' | 'water' | 'task', message: string) => {
    setIsAlarmActive(false);
    setActiveAlarmMessage("");
    setActiveAlarmType(null);
    const now = Date.now();
    const snoozeTime = 300000; // 5 mins
    if (type === 'sedentary') setMoveTargetTimestamp(now + snoozeTime);
    if (type === 'water') setWaterTargetTimestamp(now + snoozeTime);
  }, []);

  const value = useMemo(() => ({
    sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, moveTargetTimestamp, timeLeft,
    waterGoal, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTargetTimestamp, waterTimeLeft,
    tasks, settings, isAlarmActive, activeAlarmMessage, activeAlarmType,
    setSedentaryInterval, startMoveTimer, stopMoveTimer, pauseMoveTimer, resumeMoveTimer,
    updateWaterIntake, setWaterInterval, startWaterTimer, stopWaterTimer, pauseWaterTimer, resumeWaterTimer,
    addTask, removeTask, updateSettings,
    triggerAlarm, dismissAlarm, snoozeAlarm
  }), [
    sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, moveTargetTimestamp, timeLeft,
    waterGoal, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTargetTimestamp, waterTimeLeft,
    tasks, settings, isAlarmActive, activeAlarmMessage, activeAlarmType,
    setSedentaryInterval, startMoveTimer, stopMoveTimer, pauseMoveTimer, resumeMoveTimer,
    updateWaterIntake, setWaterInterval, startWaterTimer, stopWaterTimer, pauseWaterTimer, resumeWaterTimer,
    addTask, removeTask, updateSettings,
    triggerAlarm, dismissAlarm, snoozeAlarm
  ]);

  return (
    <AppStoreContext.Provider value={value}>
      {children}
    </AppStoreContext.Provider>
  );
}

export function useAppStore() {
  const context = useContext(AppStoreContext);
  if (!context) throw new Error("useAppStore missing provider");
  return context;
}
