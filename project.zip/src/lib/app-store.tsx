
"use client";

import { useState, createContext, useContext, ReactNode, useMemo, useCallback, useEffect } from "react";
import { Personality } from "./personality";

export interface Task {
  id: string;
  title: string;
  time: string;
  completed: boolean;
  repeat: "none" | "daily";
}

interface AppSettings {
  voiceEnabled: boolean;
  voiceGender: "male" | "female";
  voiceProfile: "natural" | "studio" | "funny" | "strict";
  volumeBoost: number;
  personality: Personality;
}

interface AppState {
  sedentaryInterval: number;
  isMoveTimerActive: boolean;
  isMoveTimerPaused: boolean;
  timeLeft: number;
  moveTargetTime: number | null;
  
  waterGoal: number;
  waterIntake: number;
  waterInterval: number;
  isWaterTimerActive: boolean;
  isWaterTimerPaused: boolean;
  waterTimeLeft: number;
  waterTargetTime: number | null;

  tasks: Task[];
  settings: AppSettings;
  
  isAlarmActive: boolean;
  activeAlarmMessage: string;
  activeAlarmType: 'sedentary' | 'water' | 'task' | null;
  alarmStartedAt: number | null;

  setSedentaryInterval: (val: number) => void;
  startMoveTimer: () => void;
  pauseMoveTimer: () => void;
  resumeMoveTimer: () => void;
  resetMoveTimer: () => void;
  stopMoveTimer: () => void;
  
  updateWaterIntake: (delta: number) => void;
  setWaterInterval: (val: number) => void;
  startWaterTimer: () => void;
  pauseWaterTimer: () => void;
  resumeWaterTimer: () => void;
  resetWaterTimer: () => void;
  stopWaterTimer: () => void;

  addTask: (task: Omit<Task, 'id' | 'completed'>) => void;
  removeTask: (id: string) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  
  triggerAlarm: (type: 'sedentary' | 'water' | 'task', message: string) => void;
  dismissAlarm: () => void;
  snoozeAlarm: () => void;
}

const AppStoreContext = createContext<AppState | null>(null);

export function AppStoreProvider({ children }: { children: ReactNode }) {
  // Persistence Helpers
  const save = (key: string, val: any) => {
    if (typeof window !== 'undefined') localStorage.setItem(`pulse_v2_${key}`, JSON.stringify(val));
  };
  const load = (key: string, fallback: any) => {
    if (typeof window === 'undefined') return fallback;
    const item = localStorage.getItem(`pulse_v2_${key}`);
    return item ? JSON.parse(item) : fallback;
  };

  // State initialization from localStorage (Timestamp based)
  const [sedentaryInterval, setSedentaryIntervalState] = useState(() => load('sedentary_interval', 45));
  const [isMoveTimerActive, setIsMoveTimerActive] = useState(() => load('is_move_active', false));
  const [isMoveTimerPaused, setIsMoveTimerPaused] = useState(() => load('is_move_paused', false));
  const [moveTargetTime, setMoveTargetTime] = useState<number | null>(() => load('move_target', null));
  const [timeLeft, setTimeLeftState] = useState(sedentaryInterval * 60);

  const [waterGoal] = useState(8);
  const [waterIntake, setWaterIntake] = useState(() => load('water_intake', 0));
  const [waterInterval, setWaterIntervalState] = useState(() => load('water_interval', 60));
  const [isWaterTimerActive, setIsWaterTimerActive] = useState(() => load('is_water_active', false));
  const [isWaterTimerPaused, setIsWaterTimerPaused] = useState(() => load('is_water_paused', false));
  const [waterTargetTime, setWaterTargetTime] = useState<number | null>(() => load('water_target', null));
  const [waterTimeLeft, setWaterTimeLeftState] = useState(waterInterval * 60);

  const [tasks, setTasks] = useState<Task[]>(() => load('tasks', []));
  const [settings, setSettings] = useState<AppSettings>(() => load('settings', {
    voiceEnabled: true,
    voiceGender: "female",
    voiceProfile: "natural",
    volumeBoost: 1.0,
    personality: "funny"
  }));

  const [isAlarmActive, setIsAlarmActive] = useState(false);
  const [activeAlarmMessage, setActiveAlarmMessage] = useState("");
  const [activeAlarmType, setActiveAlarmType] = useState<'sedentary' | 'water' | 'task' | null>(null);
  const [alarmStartedAt, setAlarmStartedAt] = useState<number | null>(null);

  // Sync state to localStorage on changes
  useEffect(() => {
    save('sedentary_interval', sedentaryInterval);
    save('is_move_active', isMoveTimerActive);
    save('is_move_paused', isMoveTimerPaused);
    save('move_target', moveTargetTime);
    save('water_intake', waterIntake);
    save('water_interval', waterInterval);
    save('is_water_active', isWaterTimerActive);
    save('is_water_paused', isWaterTimerPaused);
    save('water_target', waterTargetTime);
    save('tasks', tasks);
    save('settings', settings);
  }, [sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, moveTargetTime, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTargetTime, tasks, settings]);

  // Main Ticker Logic (Real-time recalculation from absolute targets)
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      
      if (isMoveTimerActive && !isMoveTimerPaused && moveTargetTime) {
        const remaining = Math.max(0, Math.floor((moveTargetTime - now) / 1000));
        setTimeLeftState(remaining);
      } else if (!isMoveTimerActive) {
        setTimeLeftState(sedentaryInterval * 60);
      }

      if (isWaterTimerActive && !isWaterTimerPaused && waterTargetTime) {
        const remaining = Math.max(0, Math.floor((waterTargetTime - now) / 1000));
        setWaterTimeLeftState(remaining);
      } else if (!isWaterTimerActive) {
        setWaterTimeLeftState(waterInterval * 60);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [isMoveTimerActive, isMoveTimerPaused, moveTargetTime, isWaterTimerActive, isWaterTimerPaused, waterTargetTime, sedentaryInterval, waterInterval]);

  // Move Logic
  const setSedentaryInterval = useCallback((val: number) => {
    setSedentaryIntervalState(val);
    if (!isMoveTimerActive) setTimeLeftState(val * 60);
  }, [isMoveTimerActive]);

  const startMoveTimer = useCallback(() => {
    const target = Date.now() + sedentaryInterval * 60 * 1000;
    setMoveTargetTime(target);
    setIsMoveTimerActive(true);
    setIsMoveTimerPaused(false);
  }, [sedentaryInterval]);

  const pauseMoveTimer = useCallback(() => setIsMoveTimerPaused(true), []);
  
  const resumeMoveTimer = useCallback(() => {
    setMoveTargetTime(Date.now() + timeLeft * 1000);
    setIsMoveTimerPaused(false);
  }, [timeLeft]);

  const resetMoveTimer = useCallback(() => {
    const target = Date.now() + sedentaryInterval * 60 * 1000;
    setMoveTargetTime(target);
    setIsMoveTimerPaused(false);
  }, [sedentaryInterval]);

  const stopMoveTimer = useCallback(() => {
    setIsMoveTimerActive(false);
    setIsMoveTimerPaused(false);
    setMoveTargetTime(null);
  }, []);

  // Water Logic
  const updateWaterIntake = useCallback((delta: number) => {
    setWaterIntake(prev => Math.max(0, prev + delta));
  }, []);

  const setWaterInterval = useCallback((val: number) => {
    setWaterIntervalState(val);
    if (!isWaterTimerActive) setWaterTimeLeftState(val * 60);
  }, [isWaterTimerActive]);

  const startWaterTimer = useCallback(() => {
    const target = Date.now() + waterInterval * 60 * 1000;
    setWaterTargetTime(target);
    setIsWaterTimerActive(true);
    setIsWaterTimerPaused(false);
  }, [waterInterval]);

  const pauseWaterTimer = useCallback(() => setIsWaterTimerPaused(true), []);

  const resumeWaterTimer = useCallback(() => {
    setWaterTargetTime(Date.now() + waterTimeLeft * 1000);
    setIsWaterTimerPaused(false);
  }, [waterTimeLeft]);

  const resetWaterTimer = useCallback(() => {
    const target = Date.now() + waterInterval * 60 * 1000;
    setWaterTargetTime(target);
    setIsWaterTimerPaused(false);
  }, [waterInterval]);

  const stopWaterTimer = useCallback(() => {
    setIsWaterTimerActive(false);
    setIsWaterTimerPaused(false);
    setWaterTargetTime(null);
  }, []);

  const addTask = useCallback((task: Omit<Task, 'id' | 'completed'>) => {
    setTasks(prev => [...prev, { ...task, id: Math.random().toString(36).substr(2, 9), completed: false }]);
  }, []);

  const removeTask = useCallback((id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  }, []);

  const updateSettings = useCallback((newS: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newS }));
  }, []);

  const triggerAlarm = useCallback((type: 'sedentary' | 'water' | 'task', message: string) => {
    setAlarmStartedAt(Date.now());
    setActiveAlarmMessage(message);
    setActiveAlarmType(type);
    setIsAlarmActive(true);
  }, []);

  const dismissAlarm = useCallback(() => {
    setIsAlarmActive(false);
    setActiveAlarmMessage("");
    setActiveAlarmType(null);
    setAlarmStartedAt(null);
  }, []);

  const snoozeAlarm = useCallback(() => {
    setIsAlarmActive(false);
    setActiveAlarmMessage("");
    setActiveAlarmType(null);
    setAlarmStartedAt(null);
  }, []);

  const value = useMemo(() => ({
    sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, timeLeft, moveTargetTime,
    waterGoal, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTimeLeft, waterTargetTime,
    tasks, settings, isAlarmActive, activeAlarmMessage, activeAlarmType, alarmStartedAt,
    setSedentaryInterval, startMoveTimer, pauseMoveTimer, resumeMoveTimer, resetMoveTimer, stopMoveTimer,
    updateWaterIntake, setWaterInterval, startWaterTimer, pauseWaterTimer, resumeWaterTimer, resetWaterTimer, stopWaterTimer,
    addTask, removeTask, updateSettings,
    triggerAlarm, dismissAlarm, snoozeAlarm
  }), [
    sedentaryInterval, isMoveTimerActive, isMoveTimerPaused, timeLeft, moveTargetTime,
    waterGoal, waterIntake, waterInterval, isWaterTimerActive, isWaterTimerPaused, waterTimeLeft, waterTargetTime,
    tasks, settings, isAlarmActive, activeAlarmMessage, activeAlarmType, alarmStartedAt,
    setSedentaryInterval, startMoveTimer, pauseMoveTimer, resumeMoveTimer, resetMoveTimer, stopMoveTimer,
    updateWaterIntake, setWaterInterval, startWaterTimer, pauseWaterTimer, resumeWaterTimer, resetWaterTimer, stopWaterTimer,
    addTask, removeTask, updateSettings,
    triggerAlarm, dismissAlarm, snoozeAlarm
  ]);

  return (
    <AppStoreContext.Provider value={value}>
      {children}
    </AppStoreContext.Provider>
  );
}

export function useAppStore() {
  const context = useContext(AppStoreContext);
  if (!context) throw new Error("useAppStore missing provider");
  return context;
}
