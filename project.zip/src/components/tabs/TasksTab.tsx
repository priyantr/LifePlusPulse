"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/app-store";
import { usePulseAlerts } from "@/hooks/use-pulse-alerts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, ListTodo, Trash2, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export function TasksTab() {
  const { tasks, addTask, removeTask, settings } = useAppStore();
  const { triggerAlert } = usePulseAlerts();
  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("");

  const handleAdd = () => {
    if (!newTitle || !newTime) return;
    
    // Calculate delay for the alert
    const now = new Date();
    const [hours, minutes] = newTime.split(':').map(Number);
    const target = new Date();
    target.setHours(hours, minutes, 0, 0);
    
    if (target < now) target.setDate(target.getDate() + 1);
    
    const delaySeconds = Math.floor((target.getTime() - now.getTime()) / 1000);
    
    addTask({ title: newTitle, time: newTime, repeat: "none" });
    
    // Explicitly pass 'task' and ensure context (task name) is passed for TTS
    triggerAlert('task', newTitle, delaySeconds);
    
    setNewTitle("");
    setNewTime("");
  };

  return (
    <div className="space-y-6">
      <div className="bento-card">
        <div className="flex items-center gap-2 mb-4">
          <Plus className="h-5 w-5 text-tasks" />
          <h3 className="font-bold">New Reminder</h3>
        </div>
        <div className="space-y-3">
          <Input 
            placeholder="What needs to be done?" 
            value={newTitle} 
            onChange={(e) => setNewTitle(e.target.value)}
            className="bg-secondary/50 border-white/5"
          />
          <div className="flex gap-2">
            <Input 
              type="time" 
              value={newTime} 
              onChange={(e) => setNewTime(e.target.value)}
              className="bg-secondary/50 border-white/5"
            />
            <Button onClick={handleAdd} className="bg-tasks hover:bg-tasks/90">Add Task</Button>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {tasks.length === 0 && (
          <div className="text-center py-10 opacity-30">
            <ListTodo className="h-12 w-12 mx-auto mb-2" />
            <p>No active pulses found.</p>
          </div>
        )}
        {tasks.map((task) => (
          <div key={task.id} className="bento-card flex items-center justify-between py-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-tasks/10">
                <Clock className="h-4 w-4 text-tasks" />
              </div>
              <div>
                <h4 className="font-bold text-sm">{task.title}</h4>
                <p className="text-xs text-muted-foreground">{task.time}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-secondary text-[10px]">SCHEDULED</Badge>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => removeTask(task.id)}
                className="text-destructive hover:bg-destructive/10"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
