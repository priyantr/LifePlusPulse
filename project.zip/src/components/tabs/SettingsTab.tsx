
"use client";

import { useState, useEffect } from "react";
import { useAppStore } from "@/lib/app-store";
import { usePulseAlerts } from "@/hooks/use-pulse-alerts";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Volume2, Mic, Smartphone, Bell, Smile } from "lucide-react";
import { Capacitor } from '@capacitor/core';
import { Badge } from "@/components/ui/badge";

export function SettingsTab() {
  const { settings, updateSettings } = useAppStore();
  const { speak, triggerAlert } = usePulseAlerts();
  const [permissionStatus, setPermissionStatus] = useState<string>("checking...");
  const isNative = typeof window !== 'undefined' && Capacitor.isNativePlatform();

  useEffect(() => {
    checkPerms();
  }, []);

  const checkPerms = async () => {
    if (typeof window === 'undefined') return;
    if (!isNative) {
      setPermissionStatus("browser_limited");
      return;
    }
    try {
      const { LocalNotifications } = await import('@capacitor/local-notifications');
      const status = await LocalNotifications.checkPermissions();
      setPermissionStatus(status.display);
    } catch (e) {
      setPermissionStatus("unsupported");
    }
  };

  const handleTestVoice = () => speak("Pulse system check. Voice personality engaged.");
  const handleTestNotification = () => triggerAlert('water');

  return (
    <div className="space-y-6">
      <div className="bento-card">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <Smile className="h-5 w-5 text-primary" />
          Pulse Personality
        </h3>
        <RadioGroup 
          value={settings.personality} 
          onValueChange={(val: any) => updateSettings({ personality: val })}
          className="grid grid-cols-2 gap-3"
        >
          {['funny', 'sarcastic', 'motivational', 'calm'].map((p) => (
            <div key={p} className={`flex items-center space-x-2 border p-3 rounded-2xl transition-all ${settings.personality === p ? 'border-primary bg-primary/10' : 'bg-white/5 border-transparent'}`}>
              <RadioGroupItem value={p} id={p} />
              <Label htmlFor={p} className="font-bold capitalize">{p}</Label>
            </div>
          ))}
        </RadioGroup>
      </div>

      <div className="bento-card">
        <h3 className="font-bold mb-6 flex items-center gap-2">
          <Mic className="h-5 w-5 text-primary" />
          Native Voice
        </h3>
        
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-sm font-bold">Enabled Alarms</Label>
              <p className="text-xs text-muted-foreground">Repeats until stopped</p>
            </div>
            <Switch 
              checked={settings.voiceEnabled} 
              onCheckedChange={(val) => updateSettings({ voiceEnabled: val })} 
            />
          </div>

          <div className="space-y-3">
            <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Voice Profile</Label>
            <RadioGroup 
              value={settings.voiceGender} 
              onValueChange={(val: any) => updateSettings({ voiceGender: val })}
              className="grid grid-cols-2 gap-4"
            >
              <div className="flex items-center space-x-2 border border-border p-4 rounded-2xl bg-white/5">
                <RadioGroupItem value="female" id="female" />
                <Label htmlFor="female" className="font-bold">Natural (F)</Label>
              </div>
              <div className="flex items-center space-x-2 border border-border p-4 rounded-2xl bg-white/5">
                <RadioGroupItem value="male" id="male" />
                <Label htmlFor="male" className="font-bold">Studio (M)</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Volume Boost</Label>
              <span className="text-xs font-bold text-primary">{Math.round(settings.volumeBoost * 100)}%</span>
            </div>
            <Slider 
              value={[settings.volumeBoost * 100]} 
              max={100} 
              step={1} 
              onValueChange={(vals) => updateSettings({ volumeBoost: vals[0] / 100 })}
              className="[&_[role=slider]]:h-6 [&_[role=slider]]:w-6"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Button variant="outline" className="rounded-2xl h-14 font-bold border-2" onClick={handleTestVoice}>
          <Volume2 className="mr-2 h-5 w-5" /> TEST VOICE
        </Button>
        <Button variant="outline" className="rounded-2xl h-14 font-bold border-2" onClick={handleTestNotification}>
          <Bell className="mr-2 h-5 w-5" /> TEST ALERT
        </Button>
      </div>
    </div>
  );
}
