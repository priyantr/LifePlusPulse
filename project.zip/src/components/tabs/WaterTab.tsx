
"use client";

import { useEffect, useRef } from "react";
import { useAppStore } from "@/lib/app-store";
import { usePulseAlerts } from "@/hooks/use-pulse-alerts";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { Plus, Minus, Timer, Bell, BellOff, Pause, Play, RotateCcw } from "lucide-react";

export function WaterTab() {
  const { 
    waterIntake, waterGoal, updateWaterIntake,
    waterInterval, setWaterInterval, 
    isWaterTimerActive, isWaterTimerPaused,
    startWaterTimer, pauseWaterTimer, resumeWaterTimer, resetWaterTimer, stopWaterTimer,
    waterTimeLeft
  } = useAppStore();
  
  const { triggerAlert, cancelNotification } = usePulseAlerts();
  const progress = (waterIntake / waterGoal) * 100;
  const lastScheduledRef = useRef<number>(0);

  useEffect(() => {
    if (isWaterTimerActive && !isWaterTimerPaused && waterTimeLeft > 0) {
      if (lastScheduledRef.current === 0) {
        triggerAlert('water', undefined, waterTimeLeft);
        lastScheduledRef.current = 1;
      }
    } else {
      if (!isWaterTimerActive) {
        lastScheduledRef.current = 0;
        cancelNotification(1002); // Explicitly kill native water notification
      }
    }
  }, [isWaterTimerActive, isWaterTimerPaused, waterTimeLeft, triggerAlert, cancelNotification]);

  const handleStart = () => {
    lastScheduledRef.current = 0;
    startWaterTimer();
  };

  const handleReset = () => {
    lastScheduledRef.current = 0;
    resetWaterTimer();
  };

  const handleStop = () => {
    lastScheduledRef.current = 0;
    stopWaterTimer();
  };

  const formatTime = (seconds: number) => {
    const s = Math.max(0, Math.floor(seconds));
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <div className="bento-card text-center py-8 relative overflow-hidden">
        <div className="absolute bottom-0 left-0 right-0 bg-water/10 transition-all duration-700" style={{ height: `${Math.min(100, progress)}%` }} />
        <div className="relative z-10">
          <div className="text-5xl font-headline font-bold text-water mb-1">
            {waterIntake} <span className="text-xl text-muted-foreground">/ {waterGoal}</span>
          </div>
          <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold">Daily Glasses Logged</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Button variant="outline" className="h-20 rounded-2xl border-2" onClick={() => updateWaterIntake(-1)}>
          <Minus className="h-6 w-6 text-water" />
        </Button>
        <Button variant="outline" className="h-20 rounded-2xl border-2 bg-water/5" onClick={() => updateWaterIntake(1)}>
          <Plus className="h-6 w-6 text-water" />
        </Button>
      </div>

      <div className="bento-card space-y-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Timer className="h-5 w-5 text-water" />
            <h3 className="font-bold">Water Pulse</h3>
          </div>
          <div className="text-2xl font-headline font-bold tabular-nums text-water">
            {formatTime(waterTimeLeft)}
          </div>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-4 gap-2">
            {[15, 30, 45, 60].map(v => (
              <Button 
                key={v} 
                variant="outline" 
                size="sm"
                className={`rounded-xl transition-all ${waterInterval === v ? "border-water text-water bg-water/10" : ""}`}
                onClick={() => setWaterInterval(v)}
              >
                {v}m
              </Button>
            ))}
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between text-xs font-bold uppercase text-muted-foreground">
              <span>Interval</span>
              <span>{waterInterval}m</span>
            </div>
            <Slider 
              value={[waterInterval]} 
              min={1} 
              max={180} 
              step={1} 
              onValueChange={(v) => setWaterInterval(v[0])}
              className="[&_[role=slider]]:bg-water"
            />
          </div>
        </div>

        <div className="flex flex-col gap-3">
          {!isWaterTimerActive ? (
            <Button 
              onClick={handleStart}
              className="w-full h-14 rounded-xl font-bold bg-water hover:bg-water/90"
            >
              <Bell className="mr-2 h-5 w-5" /> ENABLE WATER PULSE
            </Button>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {isWaterTimerPaused ? (
                <Button onClick={resumeWaterTimer} className="h-14 rounded-xl font-bold bg-water">
                  <Play className="mr-2 h-5 w-5" /> RESUME
                </Button>
              ) : (
                <Button onClick={pauseWaterTimer} variant="outline" className="h-14 rounded-xl font-bold border-2">
                  <Pause className="mr-2 h-5 w-5" /> PAUSE
                </Button>
              )}
              <Button onClick={handleStop} variant="destructive" className="h-14 rounded-xl font-bold">
                <BellOff className="mr-2 h-5 w-5" /> STOP
              </Button>
            </div>
          )}
          
          {isWaterTimerActive && (
            <Button variant="ghost" size="sm" onClick={handleReset} className="text-muted-foreground">
              <RotateCcw className="mr-2 h-4 w-4" /> Reset Water Pulse
            </Button>
          )}
        </div>
      </div>

      <div className="bento-card">
        <div className="flex justify-between mb-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground">
          <span>Target Progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-1.5 bg-secondary [&>div]:bg-water" />
      </div>
    </div>
  );
}
