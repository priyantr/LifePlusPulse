
"use client";

import { useAppStore } from "@/lib/app-store";
import { usePulseAlerts } from "@/hooks/use-pulse-alerts";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, RotateCcw, Timer, Zap, Square } from "lucide-react";

export function MoveTab() {
  const { 
    sedentaryInterval, setSedentaryInterval, 
    isMoveTimerActive, isMoveTimerPaused,
    startMoveTimer, pauseMoveTimer, resumeMoveTimer, stopMoveTimer,
    timeLeft
  } = useAppStore();
  
  const { triggerAlert, cancelNotification } = usePulseAlerts();

  const handleStart = () => {
    startMoveTimer();
    // Schedule absolute native alert
    triggerAlert('sedentary', undefined, sedentaryInterval * 60);
  };

  const handleStop = () => {
    stopMoveTimer();
    cancelNotification(1001);
  };

  const handlePause = () => {
    pauseMoveTimer();
    cancelNotification(1001);
  };

  const handleResume = () => {
    resumeMoveTimer();
    triggerAlert('sedentary', undefined, timeLeft);
  };

  const formatTime = (seconds: number) => {
    const s = Math.max(0, Math.floor(seconds));
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      <div className="bento-card text-center py-10">
        <div className="flex justify-center mb-4">
          <div className={`p-3 rounded-full ${isMoveTimerActive && !isMoveTimerPaused ? 'bg-move/20 text-move animate-pulse' : 'bg-muted text-muted-foreground'}`}>
            <Zap className="h-6 w-6" />
          </div>
        </div>
        <div className="text-6xl font-headline font-bold tabular-nums mb-6 tracking-tighter">
          {formatTime(timeLeft)}
        </div>
        
        <div className="flex flex-col gap-3">
          {!isMoveTimerActive ? (
            <Button 
              size="lg" 
              onClick={handleStart}
              className="w-full h-16 rounded-2xl text-lg font-bold bg-move hover:bg-move/90"
            >
              <Play className="mr-2 h-5 w-5" /> START MOVE PULSE
            </Button>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {isMoveTimerPaused ? (
                <Button size="lg" onClick={handleResume} className="h-16 rounded-2xl font-bold bg-move">
                  <Play className="mr-2 h-5 w-5" /> RESUME
                </Button>
              ) : (
                <Button size="lg" onClick={handlePause} variant="outline" className="h-16 rounded-2xl font-bold border-2">
                  <Pause className="mr-2 h-5 w-5" /> PAUSE
                </Button>
              )}
              <Button size="lg" onClick={handleStop} variant="destructive" className="h-16 rounded-2xl font-bold">
                <Square className="mr-2 h-5 w-5" /> DISABLE
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="bento-card">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <Timer className="h-5 w-5 text-move" />
            <h3 className="font-bold">Pulse Interval</h3>
          </div>
          <span className="text-xl font-bold text-move">{sedentaryInterval}m</span>
        </div>
        
        <div className="grid grid-cols-5 gap-2 mb-6">
          {[1, 15, 30, 45, 60].map(v => (
            <Button 
              key={v} 
              variant="outline" 
              className={`h-12 rounded-xl transition-all ${sedentaryInterval === v ? "border-move text-move bg-move/10" : ""}`}
              onClick={() => setSedentaryInterval(v)}
            >
              {v}m
            </Button>
          ))}
        </div>

        <Slider 
          value={[sedentaryInterval]} 
          min={1} 
          max={120} 
          step={1} 
          onValueChange={(v) => setSedentaryInterval(v[0])}
          className="[&_[role=slider]]:bg-move"
        />
      </div>
    </div>
  );
}
