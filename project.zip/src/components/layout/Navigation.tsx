
"use client";

import { cn } from "@/lib/utils";
import { LayoutDashboard, Timer, Droplets, ListTodo, Settings } from "lucide-react";

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: any) => void;
}

export function Navigation({ activeTab, onTabChange }: NavigationProps) {
  const navItems = [
    { id: "dashboard", icon: LayoutDashboard, label: "Home" },
    { id: "move", icon: Timer, label: "Move", color: "text-move" },
    { id: "water", icon: Droplets, label: "Water", color: "text-water" },
    { id: "tasks", icon: ListTodo, label: "Tasks", color: "text-tasks" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 glass-morphism z-50 px-6 py-4">
      <div className="max-w-2xl mx-auto flex justify-between items-center">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={cn(
              "flex flex-col items-center gap-1 transition-all duration-300",
              activeTab === item.id ? (item.color || "text-primary") : "text-muted-foreground opacity-60 hover:opacity-100"
            )}
          >
            <item.icon className={cn("h-6 w-6", activeTab === item.id && "scale-110")} />
            <span className="text-[10px] font-medium uppercase tracking-widest">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
