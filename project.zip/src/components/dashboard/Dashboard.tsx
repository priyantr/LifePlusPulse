
"use client";

import { useAppStore } from "@/lib/app-store";
import { Timer, Droplets, CheckCircle2, Zap } from "lucide-react";
import { Progress } from "@/components/ui/progress";

export function Dashboard({ onNavigate }: { onNavigate: (tab: any) => void }) {
  const { waterIntake, waterGoal, tasks, isMoveTimerActive, isWaterTimerActive } = useAppStore();
  const waterProgress = (waterIntake / waterGoal) * 100;
  const completedTasks = tasks.filter(t => t.completed).length;
  
  const isAnyPulseActive = isMoveTimerActive || isWaterTimerActive;

  return (
    <div className="grid grid-cols-2 gap-4">
      <button 
        onClick={() => onNavigate('move')}
        className="bento-card col-span-2 relative overflow-hidden group border-primary/20"
      >
        <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:scale-110 transition-transform">
          <Timer className="h-24 w-24 text-move" />
        </div>
        <div className="relative z-10 flex flex-col items-start h-full">
          <div className="flex items-center gap-2 mb-2">
            <div className={`p-2 rounded-lg ${isAnyPulseActive ? 'bg-primary/20 text-primary animate-pulse' : 'bg-muted text-muted-foreground'}`}>
              <Zap className="h-4 w-4" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              {isAnyPulseActive ? "Monitoring Active" : "Pulse Standby"}
            </span>
          </div>
          <h3 className="text-2xl font-bold mb-1">
            {isAnyPulseActive ? "Session Active" : "Session Paused"}
          </h3>
          <p className="text-muted-foreground text-sm">Sedentary monitoring and hydration pulse.</p>
        </div>
      </button>

      <button 
        onClick={() => onNavigate('water')}
        className="bento-card flex flex-col justify-between"
      >
        <div className="flex justify-between items-start mb-4">
          <div className="p-3 rounded-2xl bg-water/10 text-water">
            <Droplets className="h-6 w-6" />
          </div>
        </div>
        <div>
          <h4 className="text-sm font-bold text-muted-foreground mb-1 uppercase tracking-tighter">Hydration</h4>
          <div className="text-2xl font-bold">{waterIntake}/{waterGoal} <span className="text-xs text-muted-foreground">gl</span></div>
          <Progress value={waterProgress} className="h-1 mt-3 bg-secondary" />
        </div>
      </button>

      <button 
        onClick={() => onNavigate('tasks')}
        className="bento-card flex flex-col justify-between"
      >
        <div className="flex justify-between items-start mb-4">
          <div className="p-3 rounded-2xl bg-tasks/10 text-tasks">
            <CheckCircle2 className="h-6 w-6" />
          </div>
        </div>
        <div>
          <h4 className="text-sm font-bold text-muted-foreground mb-1 uppercase tracking-tighter">Tasks</h4>
          <div className="text-2xl font-bold">{completedTasks}/{tasks.length}</div>
          <p className="text-[10px] text-muted-foreground mt-2 uppercase tracking-widest">Efficiency pulse</p>
        </div>
      </button>
    </div>
  );
}
