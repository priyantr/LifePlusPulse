
# Life+ Pulse | Native Android Build Guide

This project is configured to be built into a real Android APK using GitHub Actions.

## How to Build on Android Phone (Using Termux)

Follow these exact steps in your Termux terminal to upload your code to GitHub and generate your APK.

### 1. Preparation
- Download the source ZIP from Firebase Studio (Cloud Icon).
- **Extract** the ZIP into a new folder in your phone's downloads (e.g., `/Download/life-plus`).

### 2. In Termux, run these commands:
```bash
# 1. Grant storage access
termux-setup-storage

# 2. Install Git
pkg install git

# 3. Go to your extracted folder (Change 'life-plus' if your folder name is different)
cd ~/storage/downloads/life-plus

# 4. Initialize Git
git init

# 5. Set your GitHub Token (Get this from GitHub Settings > Developer Settings > Tokens)
# Replace 'YOUR_TOKEN' and 'YOUR_USERNAME'
git remote add origin https://YOUR_TOKEN@github.com/YOUR_USERNAME/life-plus-pulse.git

# 6. Add and Commit
git add .
git commit -m "Build: Native Pulse Deployment"

# 7. Push to GitHub
git branch -M main
git push -u origin main
```

### 3. Get your APK
- Once pushed, go to the **Actions** tab in your GitHub repository.
- Tap the **"Build Android APK"** workflow.
- Wait ~5 minutes.
- Tap the build run, scroll to **Artifacts**, and download the ZIP containing your `.apk`.

## Important Tips
- **Exact Alarms**: After installing the APK, go to **App Info > Battery > Unrestricted** so reminders work while the screen is locked.
- **Voice**: The app will use your Android system's native high-quality TTS engine.
